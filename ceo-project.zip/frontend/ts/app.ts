declare var bootstrap: any;
let currentUser: any = null;
let currentPage = 'dashboard';
let currentPageDate = new Date();

// ===== Init =====
document.addEventListener('DOMContentLoaded', () => {
    if (api.getToken()) {
        loadApp();
    } else {
        showLogin();
    }
    initLoginForm();
});

function showLogin() {
    document.getElementById('login-screen')!.classList.remove('d-none');
    document.getElementById('app-screen')!.classList.add('d-none');
    showRoleSelection();
}

function selectRole(role: string) {
    const roles: Record<string, { username: string; label: string; avatar: string }> = {
        ceo: { username: 'ceo', label: 'Samhith — CEO', avatar: 'img/Screenshot 2026-08-20 162312.png' },
        coordinator: { username: 'soumya', label: 'Soumya — Coordinator', avatar: 'img/soumya-photo.svg' }
    };
    const r = roles[role];
    if (!r) return;
    document.getElementById('role-selection')!.classList.add('d-none');
    const formWrapper = document.getElementById('login-form-wrapper')!;
    formWrapper.classList.remove('d-none');
    document.getElementById('login-role-name')!.textContent = r.label;
    document.getElementById('login-role-avatar')!.innerHTML = `<img src="${r.avatar}" style="width:100%;height:100%;object-fit:cover;">`;
    (document.getElementById('login-username') as HTMLInputElement).value = r.username;
    (document.getElementById('login-username') as HTMLInputElement).focus();
    document.getElementById('login-error')!.classList.add('d-none');
}

function showRoleSelection() {
    document.getElementById('role-selection')!.classList.remove('d-none');
    document.getElementById('login-form-wrapper')!.classList.add('d-none');
    (document.getElementById('login-username') as HTMLInputElement).value = '';
    (document.getElementById('login-password') as HTMLInputElement).value = '';
    document.getElementById('login-error')!.classList.add('d-none');
}

function showApp() {
    document.getElementById('login-screen')!.classList.add('d-none');
    document.getElementById('app-screen')!.classList.remove('d-none');
    buildSidebar();
    showPage('dashboard');
    startNotifPolling();
    showWelcomeGreeting();
    checkWeeklyExportReminder();
}

function showWelcomeGreeting() {
    const now = new Date();
    const hour = now.getHours();
    let greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';
    const name = currentUser?.fullName || currentUser?.full_name || 'User';

    const toastEl = document.createElement('div');
    toastEl.className = 'toast toast-premium align-items-center border-0';
    toastEl.setAttribute('role', 'alert');
    toastEl.innerHTML = `
        <div class="d-flex">
            <div class="toast-body d-flex align-items-center gap-2">
                <i class="bi bi-hand-wave" style="color:var(--gold);font-size:18px"></i>
                <span><strong>${greeting}, ${name}!</strong></span>
            </div>
            <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    document.getElementById('toast-container')!.appendChild(toastEl);
    const toast = new (window as any).bootstrap.Toast(toastEl, { delay: 5000 });
    toast.show();
}

function checkWeeklyExportReminder() {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const lastDismissed = localStorage.getItem('weeklyExportDismissed');
    const todayKey = now.toISOString().split('T')[0];

    if (lastDismissed === todayKey) return;

    if (dayOfWeek === 0 || dayOfWeek === 6) {
        const toastEl = document.createElement('div');
        toastEl.className = 'toast toast-premium align-items-center border-0';
        toastEl.setAttribute('role', 'alert');
        toastEl.style.borderLeft = '4px solid var(--gold)';
        toastEl.innerHTML = `
            <div class="d-flex">
                <div class="toast-body d-flex align-items-start gap-2">
                    <i class="bi bi-cloud-download" style="color:var(--gold);font-size:20px;margin-top:2px;"></i>
                    <div>
                        <strong style="font-size:13px;">Weekly Export Reminder</strong>
                        <div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">It's the end of the week. Export your data to keep a backup.</div>
                        <div style="margin-top:8px;display:flex;gap:8px;">
                            <button class="btn btn-sm btn-gold" onclick="showPage('excel')" style="font-size:11px;padding:4px 12px;">Export Now</button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="dismissWeeklyReminder()" style="font-size:11px;padding:4px 12px;">Dismiss</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.getElementById('toast-container')!.appendChild(toastEl);
        const toast = new (window as any).bootstrap.Toast(toastEl, { delay: 30000 });
        toast.show();
    }
}

function dismissWeeklyReminder() {
    const todayKey = new Date().toISOString().split('T')[0];
    localStorage.setItem('weeklyExportDismissed', todayKey);
}

function exportAllData() {
    showToast('Preparing full export...', 'info');

    Promise.all([
        api.getSchedules(undefined, getWeekAgoDate(), getTodayDate()),
        api.getBookings(),
        api.getTasks(),
        api.getReminders(),
        api.getNotifications(),
        api.getFocusSessions()
    ]).then(([schedules, bookings, tasks, reminders, notifications, focus]) => {
        const wb = (window as any).XLSX.utils.book_new();
        const today = getTodayDate();

        if (schedules.length) {
            const scheduleData = schedules.map((s: any) => ({
                'Title': s.title,
                'Description': s.description || '',
                'Date': s.schedule_date,
                'Start Time': formatTime12(s.start_time?.substring(0,5)),
                'End Time': formatTime12(s.end_time?.substring(0,5)),
                'Type': (s.schedule_type || 'other').replace('_', ' '),
                'Location': s.location || '',
                'Participants': Array.isArray(s.participants) ? s.participants.join(', ') : (s.participants || ''),
                'Priority': s.priority || 'medium',
                'Status': s.status || 'active',
                'Reminder': s.reminder_minutes + ' min'
            }));
            const ws = (window as any).XLSX.utils.json_to_sheet(scheduleData);
            (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Schedules');
        }

        if (bookings.length) {
            const bookingData = bookings.map((b: any) => ({
                'Name': b.booked_by_name,
                'Email': b.booked_by_email,
                'Company': b.company || '',
                'Phone': b.phone || '',
                'Address': b.address || '',
                'Place': b.place || '',
                'Purpose': b.purpose || '',
                'Topic': b.what || '',
                'Date': b.booking_date,
                'Time': formatTime12(b.preferred_time?.substring(0,5)),
                'Duration': (b.duration || 30) + ' min',
                'Frequency': b.frequency || 'one-time',
                'Visitor Type': b.visitor_type || 'external',
                'Status': b.status || 'pending',
                'Notes': b.notes || ''
            }));
            const ws = (window as any).XLSX.utils.json_to_sheet(bookingData);
            (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Bookings');
        }

        if (tasks.length) {
            const taskData = tasks.map((t: any) => ({
                'Title': t.title,
                'Description': t.description || '',
                'Due Date': t.due_date || '',
                'Priority': t.priority || 'medium',
                'Status': t.status || 'pending'
            }));
            const ws = (window as any).XLSX.utils.json_to_sheet(taskData);
            (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Tasks');
        }

        if (reminders.length) {
            const reminderData = reminders.map((r: any) => ({
                'Title': r.title,
                'Description': r.description || '',
                'Date': r.reminder_date,
                'Time': formatTime12(r.reminder_time?.substring(0,5)),
                'Repeat': r.repeat_type || 'once',
                'Priority': r.priority || 'medium',
                'Status': r.status || 'pending'
            }));
            const ws = (window as any).XLSX.utils.json_to_sheet(reminderData);
            (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Reminders');
        }

        if (focus.length) {
            const focusData = focus.map((f: any) => ({
                'Title': f.title || 'Focus Time',
                'Date': f.focus_date,
                'Start': formatTime12(f.start_time?.substring(0,5)),
                'End': formatTime12(f.end_time?.substring(0,5)),
                'Status': f.status || 'active'
            }));
            const ws = (window as any).XLSX.utils.json_to_sheet(focusData);
            (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Focus Sessions');
        }

        if (wb.SheetNames.length === 0) {
            showToast('No data to export', 'warning');
            return;
        }

        const user = (currentUser?.fullName || currentUser?.full_name || 'user').toLowerCase().replace(/\s+/g, '');
        (window as any).XLSX.writeFile(wb, `next360_full_export_${user}_${today}.xlsx`);
        showToast(`Exported ${wb.SheetNames.length} sheets successfully`);
    }).catch(() => showToast('Failed to export data', 'danger'));
}

function exportSchedulesExcel() {
    api.getSchedules(undefined, getWeekAgoDate(), getTodayDate()).then((schedules: any[]) => {
        if (!schedules.length) { showToast('No schedules to export', 'warning'); return; }
        const data = schedules.map((s: any) => ({
            'Title': s.title,
            'Description': s.description || '',
            'Date': s.schedule_date,
            'Start Time': formatTime12(s.start_time?.substring(0,5)),
            'End Time': formatTime12(s.end_time?.substring(0,5)),
            'Type': (s.schedule_type || 'other').replace('_', ' '),
            'Location': s.location || '',
            'Participants': Array.isArray(s.participants) ? s.participants.join(', ') : (s.participants || ''),
            'Priority': s.priority || 'medium',
            'Status': s.status || 'active'
        }));
        const ws = (window as any).XLSX.utils.json_to_sheet(data);
        const wb = (window as any).XLSX.utils.book_new();
        (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Schedules');
        const user = (currentUser?.fullName || currentUser?.full_name || 'user').toLowerCase().replace(/\s+/g, '');
        (window as any).XLSX.writeFile(wb, `next360_schedules_${user}_${getTodayDate()}.xlsx`);
        showToast('Schedules exported');
    }).catch(() => showToast('Failed to export', 'danger'));
}

function exportTasksExcel() {
    api.getTasks().then((tasks: any[]) => {
        if (!tasks.length) { showToast('No tasks to export', 'warning'); return; }
        const data = tasks.map((t: any) => ({
            'Title': t.title,
            'Description': t.description || '',
            'Due Date': t.due_date || '',
            'Priority': t.priority || 'medium',
            'Status': t.status || 'pending'
        }));
        const ws = (window as any).XLSX.utils.json_to_sheet(data);
        const wb = (window as any).XLSX.utils.book_new();
        (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Tasks');
        const user = (currentUser?.fullName || currentUser?.full_name || 'user').toLowerCase().replace(/\s+/g, '');
        (window as any).XLSX.writeFile(wb, `next360_tasks_${user}_${getTodayDate()}.xlsx`);
        showToast('Tasks exported');
    }).catch(() => showToast('Failed to export', 'danger'));
}

function exportRemindersExcel() {
    api.getReminders().then((reminders: any[]) => {
        if (!reminders.length) { showToast('No reminders to export', 'warning'); return; }
        const data = reminders.map((r: any) => ({
            'Title': r.title,
            'Description': r.description || '',
            'Date': r.reminder_date,
            'Time': formatTime12(r.reminder_time?.substring(0,5)),
            'Repeat': r.repeat_type || 'once',
            'Priority': r.priority || 'medium',
            'Status': r.status || 'pending'
        }));
        const ws = (window as any).XLSX.utils.json_to_sheet(data);
        const wb = (window as any).XLSX.utils.book_new();
        (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Reminders');
        const user = (currentUser?.fullName || currentUser?.full_name || 'user').toLowerCase().replace(/\s+/g, '');
        (window as any).XLSX.writeFile(wb, `next360_reminders_${user}_${getTodayDate()}.xlsx`);
        showToast('Reminders exported');
    }).catch(() => showToast('Failed to export', 'danger'));
}

function getTodayDate() { return new Date().toISOString().split('T')[0]; }
function getWeekAgoDate() { const d = new Date(); d.setDate(d.getDate() - 7); return d.toISOString().split('T')[0]; }

function initLoginForm() {
    document.getElementById('login-form')!.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = (document.getElementById('login-username') as HTMLInputElement).value;
        const password = (document.getElementById('login-password') as HTMLInputElement).value;
        const btn = document.getElementById('login-btn')!;
        const errEl = document.getElementById('login-error')!;

        btn.querySelector('.btn-text')!.classList.add('d-none');
        btn.querySelector('.btn-spinner')!.classList.remove('d-none');
        errEl.classList.add('d-none');

        try {
            const result = await api.login(username, password);
            api.setToken(result.token);
            localStorage.setItem('user', JSON.stringify(result.user));
            currentUser = result.user;
            showApp();
        } catch (err: any) {
            errEl.textContent = err.error || 'Login failed';
            errEl.classList.remove('d-none');
        } finally {
            btn.querySelector('.btn-text')!.classList.remove('d-none');
            btn.querySelector('.btn-spinner')!.classList.add('d-none');
        }
    });
}

async function loadApp() {
    try {
        currentUser = await api.getMe();
        localStorage.setItem('user', JSON.stringify(currentUser));
        showApp();
    } catch {
        api.clearToken();
        showLogin();
    }
}

// ===== Sidebar =====
function buildSidebar() {
    const initial = currentUser?.fullName?.[0] || currentUser?.full_name?.[0] || 'U';
    const role = currentUser?.role === 'ceo' ? 'CEO' : 'Coordinator';

    const menuItems = [
        { id: 'dashboard', icon: 'bi-grid-1x2', label: 'Dashboard' },
        { id: 'calendar', icon: 'bi-calendar3', label: 'Calendar' },
        { id: 'schedule', icon: 'bi-clock-history', label: 'Schedule' },
        { id: 'availability', icon: 'bi-toggle2-on', label: 'Availability' },
        { id: 'bookings', icon: 'bi-calendar-check', label: 'Bookings' },
        { id: 'reminders', icon: 'bi-bell', label: 'Reminders' },
        { id: 'tasks', icon: 'bi-list-task', label: 'Tasks' },
        { id: 'notifications', icon: 'bi-inbox', label: 'Notifications' },
        { id: 'excel', icon: 'bi-file-earmark-excel', label: 'Excel Data' },
        { id: 'settings', icon: 'bi-gear', label: 'Settings' },
    ];

    const html = `
        <div class="sidebar-brand">
            <img src="img/Screenshot 2026-08-13 113539.png" alt="Next360" style="width:38px;height:38px;border-radius:10px;">
            <span>Next360</span>
        </div>
        <div class="sidebar-nav">
            ${menuItems.map(m => `
                <div class="nav-item" data-page="${m.id}" onclick="showPage('${m.id}')">
                    <i class="bi ${m.icon}"></i>
                    <span>${m.label}</span>
                    ${m.id === 'notifications' ? '<span class="badge rounded-pill d-none" id="notif-badge" style="background:var(--danger);color:white;font-size:10px;margin-left:auto;">0</span>' : ''}
                    ${m.id === 'bookings' ? '<span class="badge rounded-pill d-none" id="booking-badge" style="background:var(--warning);color:white;font-size:10px;margin-left:auto;">0</span>' : ''}
                </div>
            `).join('')}
        </div>
        <div class="sidebar-decoration">
            <div class="deco-text">"Better Decisions for a Healthier Tomorrow"</div>
        </div>
        <div class="sidebar-footer">
            <div class="user-info">
                <img src="${currentUser?.role === 'ceo' ? 'img/Screenshot 2026-08-20 162312.png' : 'img/soumya-photo.svg'}" alt="${currentUser?.full_name}" style="width:38px;height:38px;border-radius:50%;object-fit:cover;">
                <div style="flex:1;">
                    <div class="user-name">${currentUser?.fullName || currentUser?.full_name || 'User'} <span style="display:inline-block;font-size:9px;font-weight:700;padding:2px 7px;border-radius:6px;margin-left:4px;vertical-align:middle;${currentUser?.role === 'ceo' ? 'background:rgba(201,162,39,0.12);color:#C9A227;' : 'background:rgba(52,167,123,0.1);color:#3E8E68;'}">${role}</span></div>
                    <div class="user-role">${currentUser?.role === 'ceo' ? 'Chief Executive Officer' : 'CEO Coordinator'}</div>
                </div>
                <button class="btn btn-sm btn-outline-danger" onclick="handleLogout()" title="Logout" style="border-radius:8px;font-size:12px;white-space:nowrap;">
                    <i class="bi bi-box-arrow-right me-1"></i>Logout
                </button>
            </div>
        </div>
    `;

    document.getElementById('desktop-sidebar')!.innerHTML = html;
    document.getElementById('mobile-sidebar-content')!.innerHTML = `
        <div class="sidebar-nav">
            ${menuItems.map(m => `
                <div class="nav-item" data-page="${m.id}" onclick="showPage('${m.id}'); bootstrap.Offcanvas.getInstance(document.getElementById('sidebar-offcanvas'))?.hide();">
                    <i class="bi ${m.icon}"></i><span>${m.label}</span>
                </div>
            `).join('')}
        </div>
        <div class="sidebar-footer">
            <div class="user-info">
                <img src="${currentUser?.role === 'ceo' ? 'img/Screenshot 2026-08-20 162312.png' : 'img/soumya-photo.svg'}" alt="${currentUser?.full_name}" style="width:38px;height:38px;border-radius:50%;object-fit:cover;">
                <div style="flex:1;">
                    <div class="user-name">${currentUser?.fullName || currentUser?.full_name} <span style="display:inline-block;font-size:9px;font-weight:700;padding:2px 7px;border-radius:6px;margin-left:4px;vertical-align:middle;${currentUser?.role === 'ceo' ? 'background:rgba(201,162,39,0.12);color:#C9A227;' : 'background:rgba(52,167,123,0.1);color:#3E8E68;'}">${role}</span></div>
                    <div class="user-role">${currentUser?.role === 'ceo' ? 'Chief Executive Officer' : 'CEO Coordinator'}</div>
                </div>
            </div>
        </div>
    `;
}

function handleLogout() {
    api.logout().catch(() => {});
    api.clearToken();
    currentUser = null;
    window.location.reload();
}

// ===== Navigation =====
function showPage(page: string) {
    currentPage = page;
    document.querySelectorAll('.nav-item').forEach(el => {
        el.classList.toggle('active', (el as HTMLElement).dataset.page === page);
    });

    const wrapper = document.getElementById('content-wrapper')!;
    wrapper.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-forest"></div></div>';

    switch (page) {
        case 'dashboard': renderDashboard(); break;
        case 'calendar': renderCalendar(); break;
        case 'schedule': renderSchedule(); break;
        case 'availability': renderAvailability(); break;
        case 'bookings': renderBookings(); break;
        case 'reminders': renderReminders(); break;
        case 'tasks': renderTasks(); break;
        case 'notifications': renderNotifications(); break;
        case 'excel': renderExcel(); break;
        case 'settings': renderSettings(); break;
        default: renderDashboard();
    }
}

// ===== Helpers =====
function formatDate(d: Date) {
    return d.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function formatTime12(time: string) {
    if (!time) return '';
    const [h, m] = time.split(':').map(Number);
    const period = h >= 12 ? 'PM' : 'AM';
    const hr = h > 12 ? h - 12 : h === 0 ? 12 : h;
    return `${hr}:${m.toString().padStart(2, '0')} ${period}`;
}

function timeNow() {
    const d = new Date();
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
}

function showToast(message: string, type: string = 'success') {
    const icons: any = { success: 'check-circle-fill', warning: 'exclamation-triangle-fill', danger: 'x-circle-fill', info: 'info-circle-fill' };
    const colors: any = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)', info: 'var(--info)' };

    const toastEl = document.createElement('div');
    toastEl.className = 'toast toast-premium align-items-center border-0';
    toastEl.setAttribute('role', 'alert');
    toastEl.innerHTML = `
        <div class="d-flex">
            <div class="toast-body d-flex align-items-center gap-2">
                <i class="bi ${icons[type] || icons.info}" style="color:${colors[type] || colors.info}"></i>
                <span>${message}</span>
            </div>
            <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    document.getElementById('toast-container')!.appendChild(toastEl);
    const toast = new (window as any).bootstrap.Toast(toastEl, { delay: 4000 });
    toast.show();
}

function showEmptyState(icon: string, message: string) {
    return `<div class="empty-state"><i class="bi ${icon}"></i><p>${message}</p></div>`;
}

// ===== Dashboard =====
async function renderDashboard() {
    const wrapper = document.getElementById('content-wrapper')!;
    const today = new Date().toISOString().split('T')[0];
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    const greeting = now.getHours() < 12 ? 'Good Morning' : now.getHours() < 17 ? 'Good Afternoon' : 'Good Evening';

    try {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const tomorrowStr = tomorrow.toISOString().split('T')[0];

        const [scheduleStats, schedules, tasks, pendingBookings, reminders, focusSessions, tomorrowSchedules] = await Promise.all([
            api.getScheduleStats().catch(() => ({ todayMeetings: 0, freeTimeFormatted: '0h 0m' })),
            api.getSchedules(today).catch(() => []),
            api.getTaskCounts().catch(() => ({ pending: 0, today: 0, completed: 0 })),
            api.getPendingBookingsCount().catch(() => ({ count: 0 })),
            api.getActiveReminders().catch(() => []),
            api.getFocusSessions(today).catch(() => []),
            api.getSchedules(tomorrowStr).catch(() => [])
        ]);

        const nowTime = timeStr.replace(/ AM| PM/, '').trim();
        const isFocus = focusSessions.some((f: any) => nowTime >= f.start_time.substring(0,5) && nowTime <= f.end_time.substring(0,5));
        const currentMeeting = schedules.find((s: any) => nowTime >= s.start_time.substring(0,5) && nowTime <= s.end_time.substring(0,5) && s.schedule_type !== 'personal');
        const nextMeeting = schedules.find((s: any) => s.start_time.substring(0,5) > nowTime && s.status === 'active');

        let statusHtml = '<span class="status-indicator status-available"><span class="status-dot"></span>Available</span>';
        if (isFocus) statusHtml = '<span class="status-indicator status-focus-mode"><span class="status-dot"></span>Focus Mode</span>';
        else if (currentMeeting) statusHtml = '<span class="status-indicator status-meeting"><span class="status-dot"></span>In Meeting</span>';

        let nextMeetingHtml = '<div class="text-center text-muted py-4"><i class="bi bi-calendar-check" style="font-size:32px;opacity:0.2"></i><p class="mt-2 mb-0">No upcoming meetings</p></div>';
        if (nextMeeting) {
            const [nh, nm] = nextMeeting.start_time.split(':').map(Number);
            const targetTime = new Date();
            targetTime.setHours(nh, nm, 0, 0);
            const diffMs = targetTime.getTime() - now.getTime();
            const diffMin = Math.max(0, Math.floor(diffMs / 60000));
            const countdownText = diffMin <= 0 ? 'Starting now' : `Starts in ${diffMin} minutes`;

            nextMeetingHtml = `
                <div class="next-time-display">${formatTime12(nextMeeting.start_time)}</div>
                <div class="next-meeting-title">${nextMeeting.title}</div>
                ${nextMeeting.description ? `<div class="next-meta" style="font-style:italic"><i class="bi bi-chat-dots me-1"></i>${nextMeeting.description}</div>` : ''}
                ${nextMeeting.location ? `<div class="next-meta"><i class="bi bi-geo-alt me-1"></i>${nextMeeting.location}</div>` : ''}
                ${nextMeeting.participants?.length ? `<div class="next-meta"><i class="bi bi-people me-1"></i>${Array.isArray(nextMeeting.participants) ? nextMeeting.participants.join(', ') : nextMeeting.participants}</div>` : ''}
                <div class="next-meta"><i class="bi bi-clock me-1"></i>${formatTime12(nextMeeting.start_time)} - ${formatTime12(nextMeeting.end_time)}</div>
                <div class="next-meta"><i class="bi bi-tag me-1"></i>${(nextMeeting.schedule_type || 'other').replace('_', ' ')} ${nextMeeting.priority && nextMeeting.priority !== 'medium' ? '&middot; <span style="color:' + (nextMeeting.priority === 'urgent' ? '#dc3545' : nextMeeting.priority === 'high' ? '#C9A227' : '') + '">' + nextMeeting.priority + ' priority</span>' : ''}</div>
                <div class="next-countdown">${countdownText}</div>
                <button class="btn btn-sm btn-gold me-2" onclick="editSchedule('${nextMeeting.id}')"><i class="bi bi-pencil me-1"></i>Edit</button>
                <button class="btn btn-sm btn-outline-light" onclick="showPage('schedule')"><i class="bi bi-eye me-1"></i>View</button>
            `;
        }

        wrapper.innerHTML = `
            <div class="hero-banner">
                <div class="hero-top">
                    <div>
                        <div class="hero-date-badge"><i class="bi bi-calendar3"></i> Today</div>
                        <div class="hero-title">${greeting}, ${currentUser?.fullName || currentUser?.full_name || 'User'}</div>
                        <div class="hero-subtitle">${formatDate(now)} &middot; ${timeStr}</div>
                    </div>
                    <div class="hero-quote"><p>${currentUser?.role === 'ceo' ? 'Small steps today, big impact tomorrow' : 'Keeping the team on track'}</p></div>
                </div>
                <div class="hero-actions">
                    <button class="btn-hero btn-hero-search" onclick="openFindTimeModal()"><i class="bi bi-search"></i> Find Time</button>
                    <button class="btn-hero btn-hero-add" onclick="openScheduleModal()"><i class="bi bi-plus-lg"></i> Add Schedule</button>
                </div>
            </div>

            <div class="row g-3 mb-4 fade-in">
                <div class="col-6 col-lg-3">
                    <div class="stat-card forest-card">
                        <div class="stat-icon forest"><i class="bi bi-calendar-event"></i></div>
                        <div class="stat-value">${scheduleStats.todayMeetings}</div>
                        <div class="stat-label">Today's Meetings</div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="stat-card success-card">
                        <div class="stat-icon success"><i class="bi bi-clock"></i></div>
                        <div class="stat-value">${scheduleStats.freeTimeFormatted}</div>
                        <div class="stat-label">Available Time</div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="stat-card gold-card">
                        <div class="stat-icon warning"><i class="bi bi-list-task"></i></div>
                        <div class="stat-value">${tasks.pending}</div>
                        <div class="stat-label">Pending Tasks</div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="stat-card info-card">
                        <div class="stat-icon info"><i class="bi bi-calendar-plus"></i></div>
                        <div class="stat-value">${pendingBookings.count}</div>
                        <div class="stat-label">Booking Requests</div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-lg-4">
                    <div class="card-premium h-100">
                        <div class="card-header"><i class="bi bi-pie-chart me-2"></i>Task Overview</div>
                        <div class="card-body">
                            <div class="chart-container"><canvas id="taskChart"></canvas></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card-premium h-100">
                        <div class="card-header"><i class="bi bi-bar-chart me-2"></i>Weekly Activity</div>
                        <div class="card-body">
                            <div class="chart-container"><canvas id="weeklyChart"></canvas></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card-premium h-100">
                        <div class="card-header"><i class="bi bi-graph-up me-2"></i>Booking Stats</div>
                        <div class="card-body">
                            <div class="chart-container"><canvas id="bookingChart"></canvas></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-lg-5">
                    <div class="next-meeting-card slide-up">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div style="font-size:12px;text-transform:uppercase;letter-spacing:1px;opacity:0.7;font-weight:600">What's Next</div>
                        </div>
                        ${nextMeetingHtml}
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="card-premium h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-clock-history me-2"></i>Today's Timeline</span>
                            <button class="btn btn-sm btn-outline-forest" onclick="showPage('schedule')">View All</button>
                        </div>
                        <div class="card-body" style="max-height:320px;overflow-y:auto">
                            ${schedules.length === 0 ? showEmptyState('bi-calendar3', 'No schedules for today') :
                            schedules.map((s: any) => {
                                const isNow = nowTime >= s.start_time.substring(0,5) && nowTime <= s.end_time.substring(0,5);
                                const barClass = s.schedule_type === 'personal' ? 'focus' : s.schedule_type === 'review' ? 'booked' : 'busy';
                                const priorityColor = s.priority === 'urgent' ? '#dc3545' : s.priority === 'high' ? '#C9A227' : '';
                                return `
                                    <div class="timeline-item ${isNow ? 'current-time-line' : ''}" style="cursor:pointer" onclick="editSchedule('${s.id}')">
                                        <div class="timeline-time">${formatTime12(s.start_time.substring(0,5))}</div>
                                        <div class="timeline-bar ${barClass}"></div>
                                        <div class="timeline-content">
                                            <div class="event-title">${s.title} ${priorityColor ? `<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${priorityColor};margin-left:4px;vertical-align:middle"></span>` : ''}</div>
                                            <div class="event-detail">${s.location ? '<i class="bi bi-geo-alt me-1"></i>' + s.location : ''} ${s.participants?.length ? '<i class="bi bi-people me-1"></i>' + (Array.isArray(s.participants) ? s.participants.join(', ') : s.participants) : ''}</div>
                                            ${s.description ? `<div class="event-detail" style="font-style:italic;color:#999"><i class="bi bi-chat-dots me-1"></i>${s.description.length > 50 ? s.description.substring(0, 50) + '...' : s.description}</div>` : ''}
                                        </div>
                                        <span class="timeline-status status-${barClass}">${isNow ? 'NOW' : s.schedule_type?.replace('_',' ') || 'meeting'}</span>
                                    </div>`;
                            }).join('')}
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-lg-6">
                    <div class="card-premium">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-list-task me-2"></i>Today's Tasks</span>
                            <button class="btn btn-sm btn-outline-forest" onclick="showPage('tasks')">View All</button>
                        </div>
                        <div class="card-body" id="dash-tasks"></div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card-premium">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-bell me-2"></i>Reminders</span>
                            <button class="btn btn-sm btn-outline-forest" onclick="showPage('reminders')">View All</button>
                        </div>
                        <div class="card-body" id="dash-reminders"></div>
                    </div>
                </div>
            </div>

            ${tomorrowSchedules.length > 0 ? `
            <div class="card-premium mb-4" style="border-left:3px solid #C9A227;">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-calendar-event me-2" style="color:#C9A227;"></i>Tomorrow's Schedule <span style="font-size:12px;font-weight:400;color:var(--text-muted);">(${tomorrowStr})</span></span>
                    <button class="btn btn-sm btn-outline-forest" onclick="showPage('calendar')">View Calendar</button>
                </div>
                <div class="card-body" style="max-height:220px;overflow-y:auto;">
                    ${tomorrowSchedules.map((s: any) => {
                        const typeColors: Record<string, string> = { client_meeting: '#1B5E3B', employee_meeting: '#2D8B57', team_meeting: '#34A77B', interview: '#C8962E', business_meeting: '#3B82B0', review: '#8B5CF6', personal: '#E0A526', other: '#6B7280' };
                        const color = typeColors[s.schedule_type] || typeColors.other;
                        return `
                        <div style="display:flex;align-items:center;gap:12px;padding:10px 14px;margin-bottom:6px;background:${color}08;border-radius:var(--radius-sm);border-left:3px solid ${color};cursor:pointer;" onclick="editSchedule('${s.id}')">
                            <div style="text-align:center;min-width:50px;">
                                <div style="font-size:14px;font-weight:700;color:${color};">${formatTime12(s.start_time.substring(0,5))}</div>
                                <div style="font-size:10px;color:var(--text-muted);">${formatTime12(s.end_time.substring(0,5))}</div>
                            </div>
                            <div style="flex:1;min-width:0;">
                                <div style="font-size:13px;font-weight:600;color:var(--text);">${s.title}</div>
                                <div style="font-size:11px;color:var(--text-muted);">${s.location ? '<i class="bi bi-geo-alt me-1"></i>' + s.location : ''} ${s.participants?.length ? '<i class="bi bi-people me-1"></i>' + (Array.isArray(s.participants) ? s.participants.join(', ') : s.participants) : ''}</div>
                            </div>
                            <span style="font-size:10px;text-transform:uppercase;letter-spacing:0.3px;font-weight:600;padding:3px 8px;border-radius:6px;background:${color}12;color:${color};">${(s.schedule_type || 'other').replace('_', ' ')}</span>
                        </div>`;
                    }).join('')}
                </div>
            </div>
            ` : ''}

            <div class="text-center mt-4">
                <button class="btn btn-forest me-2" onclick="openScheduleModal()"><i class="bi bi-plus-lg me-1"></i>Schedule</button>
                <button class="btn btn-gold me-2" onclick="openReminderModal()"><i class="bi bi-bell me-1"></i>Reminder</button>
                <button class="btn btn-outline-forest me-2" onclick="openTaskModal()"><i class="bi bi-list-task me-1"></i>Task</button>
                <button class="btn btn-outline-forest" onclick="openBookingModal()"><i class="bi bi-calendar-plus me-1"></i>Booking</button>
            </div>
        `;

        // Load dashboard tasks
        loadDashTasks();
        loadDashReminders();
        initDashboardCharts(scheduleStats, tasks, pendingBookings);
    } catch (err) {
        wrapper.innerHTML = `<div class="alert alert-danger">Failed to load dashboard</div>`;
    }
}

async function loadDashTasks() {
    try {
        const tasks = await api.getTasks('pending');
        const el = document.getElementById('dash-tasks');
        if (!el) return;
        if (tasks.length === 0) { el.innerHTML = showEmptyState('bi-check-circle', 'No pending tasks'); return; }
        el.innerHTML = tasks.slice(0, 5).map((t: any) => `
            <div class="task-item">
                <div class="task-check ${t.status === 'completed' ? 'completed' : ''}" onclick="completeTask('${t.id}')">
                    ${t.status === 'completed' ? '<i class="bi bi-check" style="font-size:11px"></i>' : ''}
                </div>
                <div class="task-info">
                    <div class="task-title ${t.status === 'completed' ? 'completed' : ''}">${t.title}</div>
                    <div class="task-meta"><span class="priority-dot ${t.priority}"></span> ${t.priority} ${t.due_date ? '&middot; Due ' + t.due_date : ''}</div>
                </div>
            </div>
        `).join('');
    } catch {}
}

async function loadDashReminders() {
    try {
        const reminders = await api.getActiveReminders();
        const el = document.getElementById('dash-reminders');
        if (!el) return;
        if (reminders.length === 0) { el.innerHTML = showEmptyState('bi-bell', 'No active reminders'); return; }
        el.innerHTML = reminders.slice(0, 5).map((r: any) => `
            <div class="task-item">
                <span class="priority-dot ${r.priority}" style="margin-top:6px"></span>
                <div class="task-info">
                    <div class="task-title">${r.title}</div>
                    <div class="task-meta">${r.reminder_date} at ${formatTime12(r.reminder_time?.substring(0,5))} &middot; ${r.repeat_type}</div>
                </div>
            </div>
        `).join('');
    } catch {}
}

function initDashboardCharts(scheduleStats: any, tasks: any, pendingBookings: any) {
    const forestColor = '#173F35';
    const goldColor = '#C9A227';
    const successColor = '#3E8E68';
    const infoColor = '#4B7FA3';
    const warningColor = '#D99A2B';

    // Task Pie Chart
    const taskCtx = document.getElementById('taskChart') as HTMLCanvasElement;
    if (taskCtx) {
        new (window as any).Chart(taskCtx, {
            type: 'doughnut',
            data: {
                labels: ['Pending', 'Completed', 'Today'],
                datasets: [{
                    data: [tasks.pending || 1, tasks.completed || 0, tasks.today || 0],
                    backgroundColor: [warningColor, successColor, forestColor],
                    borderWidth: 0,
                    borderRadius: 4,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '65%',
                plugins: {
                    legend: { position: 'bottom', labels: { padding: 15, usePointStyle: true, pointStyleWidth: 8, font: { size: 11 } } }
                }
            }
        });
    }

    // Weekly Bar Chart
    const weeklyCtx = document.getElementById('weeklyChart') as HTMLCanvasElement;
    if (weeklyCtx) {
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
        new (window as any).Chart(weeklyCtx, {
            type: 'bar',
            data: {
                labels: days,
                datasets: [
                    { label: 'Meetings', data: [3, 5, 2, 4, scheduleStats.todayMeetings || 1], backgroundColor: forestColor, borderRadius: 4 },
                    { label: 'Tasks', data: [2, 3, 4, 1, tasks.today || 2], backgroundColor: goldColor, borderRadius: 4 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { padding: 12, usePointStyle: true, pointStyleWidth: 8, font: { size: 11 } } } },
                scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { font: { size: 10 } } }, x: { grid: { display: false }, ticks: { font: { size: 10 } } } }
            }
        });
    }

    // Booking Line Chart
    const bookingCtx = document.getElementById('bookingChart') as HTMLCanvasElement;
    if (bookingCtx) {
        new (window as any).Chart(bookingCtx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
                datasets: [{
                    label: 'Bookings',
                    data: [2, 1, 3, 0, pendingBookings.count || 1],
                    borderColor: forestColor,
                    backgroundColor: 'rgba(23,63,53,0.08)',
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: forestColor,
                    pointRadius: 4,
                    pointHoverRadius: 6,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { font: { size: 10 } } }, x: { grid: { display: false }, ticks: { font: { size: 10 } } } }
            }
        });
    }
}

// ===== Excel Export =====
function exportBookingsToExcel() {
    api.exportBookingsExcel().then((bookings: any[]) => {
        if (!bookings.length) { showToast('No bookings to export', 'warning'); return; }
        const data = bookings.map((b: any) => ({
            'Name': b.booked_by_name,
            'Email': b.booked_by_email,
            'Company': b.company,
            'Phone': b.phone,
            'Address': b.address,
            'Place': b.place,
            'Purpose': b.purpose,
            'What': b.what,
            'Date': b.booking_date,
            'Time': b.preferred_time,
            'Duration': b.duration + ' min',
            'Frequency': b.frequency,
            'Visitor Type': b.visitor_type,
            'Status': b.status,
            'Notes': b.notes
        }));
        const ws = (window as any).XLSX.utils.json_to_sheet(data);
        const wb = (window as any).XLSX.utils.book_new();
        (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Bookings');
        const user = (currentUser?.fullName || currentUser?.full_name || 'user').toLowerCase().replace(/\s+/g, '');
        (window as any).XLSX.writeFile(wb, `next360_bookings_${user}_${new Date().toISOString().split('T')[0]}.xlsx`);
        showToast('Excel file exported successfully');
    }).catch(() => showToast('Failed to export', 'danger'));
}

function uploadExcel() {
    const input = document.getElementById('excel-file-input') as HTMLInputElement;
    const file = input?.files?.[0];
    if (!file) { showToast('Please select a file', 'warning'); return; }

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const wb = (window as any).XLSX.read(e.target?.result, { type: 'array' });
            const ws = wb.Sheets[wb.SheetNames[0]];
            const data = (window as any).XLSX.utils.sheet_to_json(ws);
            showToast(`Parsed ${data.length} rows from ${file.name}`);
            const listEl = document.getElementById('excel-file-list');
            if (listEl) {
                listEl.innerHTML += `<div class="d-flex justify-content-between align-items-center p-2 rounded mb-1" style="background:rgba(62,142,104,0.06)">
                    <span style="font-size:13px"><i class="bi bi-file-earmark-excel me-2" style="color:var(--success)"></i>${file.name} (${data.length} rows)</span>
                    <span class="badge bg-success">Uploaded</span>
                </div>`;
            }
            input.value = '';
        } catch (err) {
            showToast('Failed to parse Excel file', 'danger');
        }
    };
    reader.readAsArrayBuffer(file);
}

// ===== Schedule Page =====
// ===== Schedule Page (weekly) =====
let scheduleWeekStart = '';

function dateToKey(d: Date) {
    return `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')}`;
}

function keyToDate(key: string) {
    const [y, m, d] = key.split('-').map(Number);
    return new Date(y, m - 1, d);
}

function addDaysKey(key: string, days: number) {
    const d = keyToDate(key);
    d.setDate(d.getDate() + days);
    return dateToKey(d);
}

function mondayOf(d: Date) {
    const copy = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    copy.setDate(copy.getDate() - ((copy.getDay() + 6) % 7));
    return copy;
}

function fmtMinutes(minutes: number) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return h ? `${h}h ${m ? m + 'm' : ''}`.trim() : `${m}m`;
}

function weekLabel(startKey: string) {
    const s = keyToDate(startKey);
    const e = keyToDate(addDaysKey(startKey, 6));
    const sameMonth = s.getMonth() === e.getMonth() && s.getFullYear() === e.getFullYear();
    const sTxt = s.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const eTxt = e.toLocaleDateString('en-US', sameMonth ? { day: 'numeric' } : { month: 'short', day: 'numeric' });
    return `${sTxt} – ${eTxt}, ${e.getFullYear()}`;
}

function changeScheduleWeek(delta: number) {
    const base = scheduleWeekStart || dateToKey(mondayOf(new Date()));
    scheduleWeekStart = addDaysKey(base, delta * 7);
    renderSchedule();
}

function goToThisWeek() {
    scheduleWeekStart = dateToKey(mondayOf(new Date()));
    renderSchedule();
}

function goToToday() {
    scheduleWeekStart = dateToKey(mondayOf(new Date()));
    renderSchedule();
}

async function exportScheduleCsv() {
    const start = scheduleWeekStart || dateToKey(mondayOf(new Date()));
    showToast('Preparing CSV export...', 'info');
    try {
        await api.exportSchedulesCsv(start, addDaysKey(start, 6));
        showToast('Schedule exported');
    } catch {
        showToast('Failed to export schedule', 'danger');
    }
}

function statusBadge(status: string) {
    const map: Record<string, { cls: string; label: string }> = {
        accepted: { cls: 'bg-success', label: 'Approved' },
        pending: { cls: 'bg-warning text-dark', label: 'Pending' },
        rejected: { cls: 'bg-danger', label: 'Rejected' },
        rescheduled: { cls: 'bg-info text-dark', label: 'Rescheduled' },
        cancelled: { cls: 'bg-secondary', label: 'Cancelled' }
    };
    const m = map[status] || { cls: 'bg-secondary', label: status || 'pending' };
    return `<span class="badge ${m.cls}">${m.label}</span>`;
}

function priorityLabel(p: string): string {
    const map: Record<string, string> = { low: 'Low', medium: 'Normal', high: 'High', urgent: 'Critical' };
    return map[p] || 'Normal';
}

/** Plain-text booking status label for tooltips (statusBadge renders HTML). */
function statusLabel(status: string): string {
    const map: Record<string, string> = {
        accepted: 'Approved', pending: 'Pending', rejected: 'Rejected',
        rescheduled: 'Rescheduled', cancelled: 'Cancelled'
    };
    return map[status] || status || 'pending';
}

function priorityBadge(p: string): string {
    const map: Record<string, string> = {
        low: 'background:#EEF2F0;color:#5b6b62;',
        medium: 'background:#E3F2FD;color:#1565C0;',
        high: 'background:#FFF3E0;color:#E65100;',
        urgent: 'background:#FDECEA;color:#C62828;'
    };
    return `<span class="badge" style="${map[p] || map.medium}">${priorityLabel(p)}</span>`;
}

function isCoordinator(): boolean {
    return currentUser?.role === 'coordinator';
}

/** Minute-based overlap between two HH:MM strings. */
function timesOverlap(aStart: string, aEnd: string, bStart: string, bEnd: string): boolean {
    const toMin = (t: string) => { const [h, m] = (t || '0:0').substring(0, 5).split(':').map(Number); return (h || 0) * 60 + (m || 0); };
    return toMin(aStart) < toMin(bEnd) && toMin(bStart) < toMin(aEnd);
}

function addMinutesStr(time: string, mins: number): string {
    const [h, m] = (time || '0:0').substring(0, 5).split(':').map(Number);
    const total = (h || 0) * 60 + (m || 0) + (mins || 0);
    return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}

async function renderSchedule() {
    const wrapper = document.getElementById('content-wrapper')!;
    const todayKey = dateToKey(new Date());
    if (!scheduleWeekStart) scheduleWeekStart = dateToKey(mondayOf(new Date()));
    const weekStart = scheduleWeekStart;
    const weekEnd = addDaysKey(weekStart, 6);
    const isCurrentWeek = weekStart === dateToKey(mondayOf(new Date()));

    try {
        const [overview, schedules, bookings] = await Promise.all([
            api.getWeekOverview(weekStart, weekEnd),
            // The CEO only sees the CEO calendar; the coordinator sees the shared
            // coordination view (her own entries + everything on the CEO's calendar).
            api.getSchedules(undefined, weekStart, weekEnd, currentUser?.role === 'ceo' ? 'mine' : 'all'),
            api.getBookings()
        ]);

        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const typeColors: Record<string, string> = {
            client_meeting: '#1B5E3B',
            employee_meeting: '#2D8B57',
            team_meeting: '#34A77B',
            interview: '#C8962E',
            business_meeting: '#3B82B0',
            review: '#8B5CF6',
            personal: '#E0A526',
            other: '#6B7280'
        };
        const activeStatuses = ['pending', 'accepted'];

        const todaysAppointments = bookings
            .filter((b: any) => b.booking_date === todayKey && activeStatuses.includes(b.status))
            .sort((a: any, b: any) => String(a.preferred_time).localeCompare(String(b.preferred_time)));
        const upcomingAppointments = bookings
            .filter((b: any) => b.booking_date > todayKey && activeStatuses.includes(b.status))
            .sort((a: any, b: any) => a.booking_date.localeCompare(b.booking_date) || String(a.preferred_time).localeCompare(String(b.preferred_time)))
            .slice(0, 6);

        const appointmentRow = (b: any, showDate: boolean) => `
            <div class="appt-row" onclick="viewAppointmentDetails('${b.id}')">
                <div class="appt-time">
                    <strong>${formatTime12(b.preferred_time?.substring(0, 5))}</strong>
                    <span>${showDate ? b.booking_date : (b.duration || 30) + ' min'}</span>
                </div>
                <div class="appt-info">
                    <div class="appt-name">${b.booked_by_name}</div>
                    <div class="appt-purpose">${b.purpose || b.what || 'Meeting request'}</div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    ${statusBadge(b.status)}
                    <i class="bi bi-chevron-right" style="color:var(--text-muted);font-size:12px;"></i>
                </div>
            </div>`;

        // Minute-based overlap map across schedules + active bookings for the week,
        // so conflicting meetings are flagged instead of silently overlapping.
        const conflictMap: Record<string, string[]> = {};
        overview.days.forEach((day: any) => {
            const evts = [
                ...schedules.filter((s: any) => s.schedule_date === day.date)
                    .map((s: any) => ({ id: s.id, title: s.title, start: s.start_time, end: s.end_time })),
                ...bookings.filter((b: any) => b.booking_date === day.date && activeStatuses.includes(b.status))
                    .map((b: any) => ({ id: b.id, title: `Booking: ${b.booked_by_name}`, start: b.preferred_time, end: addMinutesStr(b.preferred_time, b.duration || 30) }))
            ];
            evts.forEach((e: any, i: number) => {
                evts.forEach((o: any, j: number) => {
                    if (i < j && timesOverlap(e.start, e.end, o.start, o.end)) {
                        (conflictMap[e.id] = conflictMap[e.id] || []).push(o.title);
                        (conflictMap[o.id] = conflictMap[o.id] || []).push(e.title);
                    }
                });
            });
        });

        const weekColumns = overview.days.map((day: any) => {
            const isToday = day.date === todayKey;
            const daySchedules = schedules.filter((s: any) => s.schedule_date === day.date);
            const dayBookings = bookings.filter((b: any) => b.booking_date === day.date && activeStatuses.includes(b.status));
            const freeLabel = day.freeMinutes > 0
                ? `${fmtMinutes(day.freeMinutes)} free`
                : (day.workingMinutes === 0 ? 'Closed' : 'Fully booked');

            const eventsHtml = daySchedules.map((s: any) => {
                const color = typeColors[s.schedule_type] || typeColors.other;
                const isCeo = s.is_ceo_appointment === true;
                const conflictList = conflictMap[s.id] || [];
                const conflictChip = conflictList.length
                    ? `<div class="week-event-conflict-chip" title="Overlaps: ${conflictList.join(', ')}"><i class="bi bi-exclamation-triangle-fill"></i> overlap</div>`
                    : '';
                return `
                    <div class="week-event${isCeo ? ' is-ceo' : ''}${conflictList.length ? ' is-conflict' : ''}" onclick="editSchedule('${s.id}')"
                        title="${s.title}${s.location ? '\nAt: ' + s.location : ''}${s.description ? '\n' + s.description : ''}${conflictList.length ? '\nOverlaps: ' + conflictList.join(', ') : ''}">
                        <span class="week-event-bar" style="background:${color};"></span>
                        <div class="week-event-body">
                            <div class="week-event-time">${formatTime12(s.start_time?.substring(0, 5))} ${priorityBadge(s.priority)}</div>
                            <div class="week-event-title">${s.title}${isCeo ? ' <span class="week-event-ceo">CEO</span>' : ''}</div>
                            <div class="week-event-owner">${isCeo ? 'CEO appointment' : (s.creator_name || '')}</div>
                            ${conflictChip}
                        </div>
                    </div>`;
            }).join('');

            const bookingsHtml = dayBookings.map((b: any) => {
                const conflictList = conflictMap[b.id] || [];
                const conflictChip = conflictList.length
                    ? `<div class="week-event-conflict-chip" title="Overlaps: ${conflictList.join(', ')}"><i class="bi bi-exclamation-triangle-fill"></i> overlap</div>`
                    : '';
                return `
                <div class="week-event is-booking${b.status === 'pending' ? ' is-pending' : ''}${conflictList.length ? ' is-conflict' : ''}" onclick="viewAppointmentDetails('${b.id}')" title="Appointment with ${b.booked_by_name}${conflictList.length ? '\nOverlaps: ' + conflictList.join(', ') : ''}">
                    <span class="week-event-bar" style="background:var(--gold);"></span>
                    <div class="week-event-body">
                        <div class="week-event-time">${formatTime12(b.preferred_time?.substring(0, 5))} ${statusBadge(b.status)}</div>
                        <div class="week-event-title">${b.booked_by_name}</div>
                        <div class="week-event-owner">${b.status === 'pending' ? 'Awaiting approval' : 'Appointment'}</div>
                        ${conflictChip}
                    </div>
                </div>`;
            }).join('');

            return `
                <div class="week-col${isToday ? ' is-today' : ''}">
                    <div class="week-day-head">
                        <span class="week-day-name">${dayNames[keyToDate(day.date).getDay()]}</span>
                        <span class="week-day-num">${keyToDate(day.date).getDate()}</span>
                    </div>
                    <div class="week-day-body">
                        ${eventsHtml || ''}
                        ${bookingsHtml || ''}
                        ${!daySchedules.length && !dayBookings.length ? '<div class="week-empty">No events</div>' : ''}
                        <button class="week-add" onclick="openScheduleModal(null,null,'${day.date}')"><i class="bi bi-plus-lg"></i> Add</button>
                    </div>
                    <div class="week-free${day.freeMinutes === 0 ? ' is-full' : ''}">
                        <i class="bi bi-clock"></i> ${freeLabel}
                    </div>
                </div>`;
        }).join('');

        wrapper.innerHTML = `
            <div class="content-header">
                <div>
                    <h4>Schedule</h4>
                    <div class="subtitle">${weekLabel(weekStart)}</div>
                </div>
                <div class="d-flex gap-2 align-items-center flex-wrap">
                    <button class="btn btn-sm ${isCurrentWeek ? 'btn-outline-forest' : 'btn-gold'}" onclick="goToToday()">Today</button>
                    <button class="btn btn-sm btn-outline-forest" onclick="goToThisWeek()">This Week</button>
                    <button class="btn btn-sm btn-gold" onclick="openScheduleModal()"><i class="bi bi-plus-lg me-1"></i>Add Schedule</button>
                    <button class="btn btn-sm btn-outline-forest" onclick="exportScheduleCsv()"><i class="bi bi-download me-1"></i>Export CSV</button>
                </div>
            </div>

            <div class="row g-3 mb-4 fade-in">
                <div class="col-6 col-lg-3">
                    <div class="stat-card forest-card">
                        <div class="stat-icon forest"><i class="bi bi-calendar-event"></i></div>
                        <div class="stat-value">${schedules.length}</div>
                        <div class="stat-label">Events This Week</div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="stat-card gold-card">
                        <div class="stat-icon warning"><i class="bi bi-hourglass-split"></i></div>
                        <div class="stat-value">${fmtMinutes(overview.totals.bookedMinutes)}</div>
                        <div class="stat-label">Booked</div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="stat-card success-card">
                        <div class="stat-icon success"><i class="bi bi-unlock"></i></div>
                        <div class="stat-value">${fmtMinutes(overview.totals.availableMinutes)}</div>
                        <div class="stat-label">Available</div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="stat-card info-card">
                        <div class="stat-icon info"><i class="bi bi-people"></i></div>
                        <div class="stat-value">${overview.totals.appointmentsToday}</div>
                        <div class="stat-label">Appointments Today</div>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-3">
                <button class="btn btn-outline-forest btn-sm" onclick="changeScheduleWeek(-1)"><i class="bi bi-chevron-left me-1"></i>Previous Week</button>
                <span style="font-weight:700;font-size:13.5px;color:var(--forest);letter-spacing:0.2px;">${weekLabel(weekStart)}</span>
                <button class="btn btn-outline-forest btn-sm" onclick="changeScheduleWeek(1)">Next Week<i class="bi bi-chevron-right ms-1"></i></button>
            </div>

            <div class="card-premium week-card mb-4">
                <div class="week-grid">${weekColumns}</div>
            </div>

            <div class="row g-3">
                <div class="col-lg-6">
                    <div class="card-premium">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span style="font-weight:700;font-size:13px;color:var(--forest);text-transform:uppercase;letter-spacing:0.5px;"><i class="bi bi-calendar-check me-2"></i>Today's Appointments</span>
                            <span class="badge rounded-pill" style="background:var(--green-soft);color:var(--forest);">${todaysAppointments.length}</span>
                        </div>
                        <div class="card-body p-0">
                            ${todaysAppointments.length ? todaysAppointments.map((b: any) => appointmentRow(b, false)).join('') : showEmptyState('bi-calendar-check', 'No appointments today')}
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card-premium">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span style="font-weight:700;font-size:13px;color:var(--forest);text-transform:uppercase;letter-spacing:0.5px;"><i class="bi bi-arrow-right-circle me-2"></i>Upcoming</span>
                            <span class="badge rounded-pill" style="background:var(--green-soft);color:var(--forest);">${upcomingAppointments.length}</span>
                        </div>
                        <div class="card-body p-0">
                            ${upcomingAppointments.length ? upcomingAppointments.map((b: any) => appointmentRow(b, true)).join('') : showEmptyState('bi-arrow-right-circle', 'No upcoming appointments')}
                        </div>
                    </div>
                </div>
            </div>
        `;
    } catch (err) {
        wrapper.innerHTML = '<div class="alert alert-danger">Failed to load schedule</div>';
    }
}

async function viewAppointmentDetails(id: string, conflict?: any) {
    try {
        const b = await api.get<any>(`/bookings/${id}`);
        const modal = new (window as any).bootstrap.Modal(document.getElementById('appointmentModal'));
        const row = (label: string, value: any) => `
            <div class="col-md-6 mb-3">
                <div style="font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-muted);font-weight:600;margin-bottom:3px;">${label}</div>
                <div style="font-size:13.5px;color:var(--text);font-weight:500;">${value || '—'}</div>
            </div>`;

        const conflictList = (conflict?.conflicts || [])
            .map((c: any) => `&bull; <strong>${c.title}</strong> (${c.priorityLabel || priorityLabel(c.priority)}) ${formatTime12(c.startTime)}-${formatTime12(c.endTime)}${c.ownerName ? ' \u2014 ' + c.ownerName : ''}`)
            .join('<br>');
        const conflictBlock = conflict ? `
            <div class="alert alert-warning mb-3">
                <strong><i class="bi bi-exclamation-triangle me-1"></i>Approving this booking would overlap an existing CEO meeting.</strong>
                <div class="mt-1" style="font-size:12.5px;">${conflict.conflicts?.length ? conflict.conflicts.map((c: any) => `&bull; <strong>${c.title}</strong> (${c.priorityLabel || priorityLabel(c.priority)}) ${formatTime12(c.startTime)}-${formatTime12(c.endTime)}${c.ownerName ? ' \u2014 ' + c.ownerName : ''}`).join('<br>') : (conflict.error || 'Time conflict detected')}</div>
                <div class="d-flex flex-wrap gap-2 mt-2">
                    <button class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-sm btn-outline-forest" onclick="openRescheduleModal('${b.id}','${b.booking_date}','${(b.preferred_time || '').substring(0,5)}',${b.duration || 30})"><i class="bi bi-calendar-event me-1"></i>Reschedule</button>
                    <button class="btn btn-sm btn-danger" onclick="confirmOverrideApprove('${b.id}')"><i class="bi bi-exclamation-triangle me-1"></i>Override &amp; Approve</button>
                </div>
            </div>` : '';

        document.getElementById('appt-modal-body')!.innerHTML = `
            <div class="d-flex align-items-center justify-content-between mb-3 pb-3" style="border-bottom:1px solid var(--border-light);">
                <div>
                    <div style="font-size:16px;font-weight:700;color:var(--forest);">${b.booked_by_name}</div>
                    <div style="font-size:12.5px;color:var(--text-muted);">${b.company || b.email || ''}</div>
                </div>
                ${statusBadge(b.status)}
            </div>
            ${conflictBlock}
            <div class="row">
                ${row('Date', `${b.booking_date} (${keyToDate(b.booking_date).toLocaleDateString('en-US', { weekday: 'long' })})`)}
                ${row('Time', `${formatTime12(b.preferred_time?.substring(0, 5))} · ${b.duration || 30} min`)}
                ${row('Priority', b.schedule_priority ? priorityBadge(b.schedule_priority) : 'Set when the meeting is scheduled')}
                ${row('Email', b.email || b.booked_by_email)}
                ${row('Phone', b.phone)}
                ${row('Company / Organization', b.company)}
                ${row('Visitor Type', (b.visitor_type || '').replace('_', ' '))}
                ${row('Address', b.address)}
                ${row('City / Place', b.place)}
                ${row('Meeting Type', (b.what || '').replace('_', ' '))}
                ${row('Frequency', b.frequency)}
                ${row('Purpose', b.purpose)}
                ${row('Additional Notes', b.notes)}
            </div>
            <div class="d-flex justify-content-between align-items-center mb-3 pb-3" style="border-top:1px solid var(--border-light);padding-top:14px;">
                <span style="font-size:12px;color:var(--text-muted);">${b.status === 'pending' ? 'This request is awaiting the coordinator\u2019s approval.' : (b.status === 'accepted' ? 'Approved \u00b7 added to the CEO calendar.' : (b.status === 'rescheduled' ? 'Rescheduled \u00b7 CEO calendar updated.' : 'Not a confirmed meeting.'))}</span>
            </div>
            <div class="modal-footer px-0 pb-0 mt-2" style="border-top:none;">
                <button class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                ${isCoordinator() && !conflict ? `
                    <button class="btn btn-sm btn-outline-forest" onclick="openRescheduleModal('${b.id}','${b.booking_date}','${(b.preferred_time || '').substring(0,5)}',${b.duration || 30})"><i class="bi bi-calendar-event me-1"></i>Reschedule</button>
                    ${b.status === 'pending' ? `
                        <button class="btn btn-sm btn-outline-danger" onclick="setAppointmentStatus('${b.id}','rejected')"><i class="bi bi-x-lg me-1"></i>Reject</button>
                        <button class="btn btn-sm btn-gold" onclick="setAppointmentStatus('${b.id}','accepted')"><i class="bi bi-check-lg me-1"></i>Approve</button>
                    ` : ''}
                ` : ''}
            </div>
        `;
        modal.show();
    } catch {
        showToast('Failed to load appointment', 'danger');
    }
}

/** Confirmed override-and-approve after an explicit confirmation. */
async function confirmOverrideApprove(id: string) {
    if (!confirm('Override the conflict and approve this booking? The override is recorded in the audit trail.')) return;
    try {
        await api.updateBookingStatus(id, 'accepted', { overrideConflict: true });
        bootstrap.Modal.getInstance(document.getElementById('appointmentModal'))?.hide();
        showToast('Booking approved with conflict override');
        if (currentPage === 'bookings') renderBookings();
        else if (currentPage === 'schedule') renderSchedule();
        else if (currentPage === 'calendar') renderCalendar();
    } catch (err: any) {
        showToast(err.error || 'Failed to approve booking', 'danger');
    }
}

async function setAppointmentStatus(id: string, status: string) {
    try {
        await api.updateBookingStatus(id, status);
        bootstrap.Modal.getInstance(document.getElementById('appointmentModal'))?.hide();
        showToast(status === 'accepted' ? 'Booking approved' : `Appointment ${status}`);
        if (currentPage === 'schedule') renderSchedule();
        else if (currentPage === 'bookings') renderBookings();
    } catch (err: any) {
        if (err.hasConflict) {
            showToast('This booking overlaps an existing meeting', 'warning');
            viewAppointmentDetails(id, err);
        } else {
            showToast(err.error || 'Failed to update appointment', 'danger');
        }
    }
}

function openRescheduleModal(id: string, date: string, time: string, duration: number) {
    (document.getElementById('res-id') as HTMLInputElement).value = id;
    (document.getElementById('res-date') as HTMLInputElement).value = date || dateToKey(new Date());
    (document.getElementById('res-time') as HTMLInputElement).value = (time || '09:00').substring(0, 5);
    (document.getElementById('res-duration') as HTMLSelectElement).value = String(duration || 30);
    (document.getElementById('res-reason') as HTMLInputElement).value = '';
    document.getElementById('res-conflict-alert')!.classList.add('d-none');
    document.getElementById('res-summary')!.textContent = 'Move this booking to a new time. If it overlaps an existing CEO meeting you will be asked to confirm.';
    bootstrap.Modal.getInstance(document.getElementById('appointmentModal'))?.hide();
    new (window as any).bootstrap.Modal(document.getElementById('rescheduleModal')).show();
}

async function submitReschedule(overrideConflict: boolean) {
    const id = (document.getElementById('res-id') as HTMLInputElement).value;
    const date = (document.getElementById('res-date') as HTMLInputElement).value;
    const time = (document.getElementById('res-time') as HTMLInputElement).value;
    const duration = parseInt((document.getElementById('res-duration') as HTMLSelectElement).value);
    const reason = (document.getElementById('res-reason') as HTMLInputElement).value;
    const alert = document.getElementById('res-conflict-alert')!;

    if (!date || !time) { showToast('Please choose a date and time', 'warning'); return; }

    try {
        await api.rescheduleBooking(id, { date, time, duration, reason, overrideConflict });
        bootstrap.Modal.getInstance(document.getElementById('rescheduleModal'))?.hide();
        showToast(overrideConflict ? 'Rescheduled (conflict override recorded)' : 'Booking rescheduled');
        if (currentPage === 'schedule') renderSchedule();
        else if (currentPage === 'bookings') renderBookings();
    } catch (err: any) {
        if (err.hasConflict) {
            const list = (err.conflicts || []).map((c: any) => `&bull; <strong>${c.title}</strong> (${c.priorityLabel || c.priority}) ${formatTime12(c.startTime)}-${formatTime12(c.endTime)}`).join('<br>');
            alert.innerHTML = `<i class="bi bi-exclamation-triangle me-2"></i><strong>${err.error || 'Conflict'}</strong><br>${list}
                <div class="d-flex flex-wrap gap-2 mt-2">
                    <button class="btn btn-sm btn-outline-secondary" onclick="window.bootstrap?.Modal?.getInstance(document.getElementById('rescheduleModal'))?.hide()">Cancel</button>
                    <button class="btn btn-sm btn-outline-forest" onclick="document.getElementById('res-conflict-alert').classList.add('d-none');document.getElementById('res-time').focus()">Adjust Time</button>
                    <button class="btn btn-sm btn-danger" onclick="confirmAndOverrideReschedule()"><i class="bi bi-exclamation-triangle me-1"></i>Override and reschedule</button>
                </div>`;
            alert.classList.remove('d-none');
        } else {
            showToast(err.error || 'Failed to reschedule', 'danger');
        }
    }
}

// ===== Calendar Page =====
async function renderCalendar() {
    const wrapper = document.getElementById('content-wrapper')!;
    const year = currentPageDate.getFullYear();
    const month = currentPageDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();

    const startDate = `${year}-${(month+1).toString().padStart(2,'0')}-01`;
    const endDate = `${year}-${(month+1).toString().padStart(2,'0')}-${daysInMonth.toString().padStart(2,'0')}`;

    try {
        const [schedules, bookings] = await Promise.all([
            api.getSchedules(undefined, startDate, endDate, currentUser?.role === 'ceo' ? 'mine' : 'all'),
            api.getBookings()
        ]);

        // Overlap detection across the month for confirmed appointments + active
        // booking requests, using the same minute-based rule as the week view.
        const activeStatuses = ['pending', 'accepted'];
        const conflictMap: Record<string, string[]> = {};
        const monthEvents = [
            ...schedules.map((s: any) => ({ id: s.id, date: s.schedule_date, start: s.start_time, end: s.end_time, title: s.title })),
            ...bookings.filter((b: any) => activeStatuses.includes(b.status))
                .map((b: any) => ({ id: b.id, date: b.booking_date, start: b.preferred_time, end: addMinutesStr(b.preferred_time, b.duration || 30), title: `Booking: ${b.booked_by_name}` }))
        ];
        const eventsByDate: Record<string, any[]> = {};
        monthEvents.forEach((e: any) => { (eventsByDate[e.date] = eventsByDate[e.date] || []).push(e); });
        Object.keys(eventsByDate).forEach(dateKey => {
            const list = eventsByDate[dateKey];
            list.forEach((e: any, i: number) => list.forEach((o: any, j: number) => {
                if (i < j && timesOverlap(e.start, e.end, o.start, o.end)) {
                    (conflictMap[e.id] = conflictMap[e.id] || []).push(o.title);
                    (conflictMap[o.id] = conflictMap[o.id] || []).push(e.title);
                }
            }));
        });

        const monthName = currentPageDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

        let daysHtml = '';
        for (let i = 0; i < firstDay; i++) {
            daysHtml += '<div class="calendar-day other-month"></div>';
        }
        for (let d = 1; d <= daysInMonth; d++) {
            const dateStr = `${year}-${(month+1).toString().padStart(2,'0')}-${d.toString().padStart(2,'0')}`;
            const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === d;
            const daySchedules = schedules.filter((s: any) => s.schedule_date === dateStr);
            const dayBookings = bookings.filter((b: any) => b.booking_date === dateStr && activeStatuses.includes(b.status));

            const scheduleItems = daySchedules.map((s: any) => {
                const overlaps = conflictMap[s.id] || [];
                const conflict = overlaps.length > 0;
                const tip = `${s.title}\n${formatTime12(s.start_time?.substring(0,5))}-${formatTime12(s.end_time?.substring(0,5))}\n${priorityLabel(s.priority)} priority${s.location ? '\nAt: ' + s.location : ''}${conflict ? '\nOverlaps: ' + overlaps.join(', ') : ''}`;
                return `<div class="calendar-event meeting${s.is_ceo_appointment ? ' is-ceo' : ''}${conflict ? ' is-conflict' : ''}" title="${tip}" onclick="event.stopPropagation();editSchedule('${s.id}')">
                    <span class="priority-dot ${s.priority || 'medium'}"></span>
                    <span class="cal-event-time">${formatTime12(s.start_time?.substring(0,5))}</span> ${s.title}${s.is_ceo_appointment ? ' <span class="week-event-ceo">CEO</span>' : ''}${conflict ? ' <i class="bi bi-exclamation-triangle-fill conflict-icon"></i>' : ''}
                </div>`;
            });
            const bookingItems = dayBookings.map((b: any) => {
                const overlaps = conflictMap[b.id] || [];
                const conflict = overlaps.length > 0;
                const tip = `Appointment: ${b.booked_by_name}\n${formatTime12(b.preferred_time?.substring(0,5))} · ${b.duration || 30} min\nStatus: ${statusLabel(b.status)}${conflict ? '\nOverlaps: ' + overlaps.join(', ') : ''}`;
                return `
                    <div class="calendar-event meeting is-booking${conflict ? ' is-conflict' : ''}" title="${tip}" onclick="event.stopPropagation();viewAppointmentDetails('${b.id}')">${formatTime12(b.preferred_time?.substring(0,5))} ${b.booked_by_name}${conflict ? ' <i class="bi bi-exclamation-triangle-fill"></i>' : ''}</div>
                `;
            });
            const items = [...scheduleItems, ...bookingItems];

            daysHtml += `
                <div class="calendar-day ${isToday ? 'today' : ''}" onclick="currentPageDate=new Date(${year},${month},${d});openScheduleModal(null,null,'${dateStr}')">
                    <div class="day-number">${d}</div>
                    ${items.slice(0,3).join('')}
                    ${items.length > 3 ? `<div style="font-size:10px;color:#888">+${items.length - 3} more</div>` : ''}
                </div>`;
        }

        wrapper.innerHTML = `
            <div class="content-header">
                <div>
                    <h4>Calendar</h4>
                    <div class="subtitle">${monthName}</div>
                </div>
                <div class="d-flex gap-2 align-items-center">
                    <button class="btn btn-outline-forest btn-sm" onclick="changeMonth(-1)"><i class="bi bi-chevron-left"></i></button>
                    <span class="fw-semibold">${monthName}</span>
                    <button class="btn btn-outline-forest btn-sm" onclick="changeMonth(1)"><i class="bi bi-chevron-right"></i></button>
                    <button class="btn btn-gold ms-2" onclick="openScheduleModal()"><i class="bi bi-plus-lg me-1"></i>Add</button>
                </div>
            </div>
            <div class="card-premium p-3">
                <div class="calendar-grid">
                    ${dayNames.map(d => `<div class="calendar-header-cell">${d}</div>`).join('')}
                    ${daysHtml}
                </div>
            </div>
        `;
    } catch (err) {
        wrapper.innerHTML = '<div class="alert alert-danger">Failed to load calendar</div>';
    }
}

function changeMonth(delta: number) {
    currentPageDate.setMonth(currentPageDate.getMonth() + delta);
    renderCalendar();
}

// ===== Availability Page =====
async function renderAvailability() {
    const wrapper = document.getElementById('content-wrapper')!;
    try {
        const availability = await api.getAvailability();
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        wrapper.innerHTML = `
            <div class="content-header">
                <div>
                    <h4>Availability</h4>
                    <div class="subtitle">Manage your available hours</div>
                </div>
                <button class="btn btn-gold" onclick="addAvailability()"><i class="bi bi-plus-lg me-1"></i>Add Slot</button>
            </div>
            <div class="row g-3">
                ${days.map((day, i) => {
                    const slots = availability.filter((a: any) => a.day_of_week === i);
                    return `
                        <div class="col-md-6 col-lg-4">
                            <div class="card-premium">
                                <div class="card-header fw-semibold">${day}</div>
                                <div class="card-body">
                                    ${slots.length === 0 ? '<div class="text-muted" style="font-size:12px">No availability set</div>' :
                                    slots.map((s: any) => `
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span style="font-size:13px">${formatTime12(s.start_time?.substring(0,5))} - ${formatTime12(s.end_time?.substring(0,5))}</span>
                                            <span class="badge ${s.is_available ? 'bg-success' : 'bg-secondary'}">${s.is_available ? 'Available' : 'Blocked'}</span>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        </div>`;
                }).join('')}
            </div>
        `;
    } catch (err) {
        wrapper.innerHTML = '<div class="alert alert-danger">Failed to load availability</div>';
    }
}

async function addAvailability() {
    const day = prompt('Day of week (0=Sun, 1=Mon, ..., 6=Sat):');
    if (day === null) return;
    const start = prompt('Start time (HH:MM):');
    const end = prompt('End time (HH:MM):');
    if (!start || !end) return;

    try {
        await api.upsertAvailability({ dayOfWeek: parseInt(day), startTime: start, endTime: end, isAvailable: true });
        showToast('Availability updated');
        renderAvailability();
    } catch (err: any) {
        showToast(err.error || 'Failed', 'danger');
    }
}

// ===== Bookings Page =====
async function renderBookings() {
    const wrapper = document.getElementById('content-wrapper')!;
    try {
        const bookings = await api.getBookings();

        wrapper.innerHTML = `
            <div class="content-header">
                <div>
                    <h4>Bookings</h4>
                    <div class="subtitle">Manage booking requests</div>
                </div>
                <button class="btn btn-gold" onclick="openBookingModal()"><i class="bi bi-plus-lg me-1"></i>New Booking</button>
            </div>
            <div class="d-flex gap-2 mb-3 flex-wrap">
                <button class="btn btn-sm btn-outline-forest active" onclick="filterBookings('all',this)">All</button>
                <button class="btn btn-sm btn-outline-forest" onclick="filterBookings('pending',this)">Pending</button>
                <button class="btn btn-sm btn-outline-forest" onclick="filterBookings('accepted',this)">Approved</button>
                <button class="btn btn-sm btn-outline-forest" onclick="filterBookings('rescheduled',this)">Rescheduled</button>
                <button class="btn btn-sm btn-outline-forest" onclick="filterBookings('rejected',this)">Rejected</button>
            </div>
            ${isCoordinator() ? '' : '<div class="alert alert-info py-2" style="font-size:12.5px;"><i class="bi bi-info-circle me-1"></i>Booking requests are approved by the coordinator (Soumya).</div>'}
            <div class="card-premium">
                <div class="card-body p-0">
                    ${bookings.length === 0 ? showEmptyState('bi-calendar-check', 'No bookings yet') : `
                    <div class="table-responsive">
                        <table class="table table-premium mb-0">
                            <thead><tr><th>Name</th><th>Company</th><th>Date</th><th>Time</th><th>Purpose</th><th>Priority</th><th>Status</th><th>Actions</th></tr></thead>
                            <tbody>
                                ${bookings.map((b: any) => `
                                    <tr data-status="${b.status}">
                                        <td class="fw-semibold">${b.booked_by_name}</td>
                                        <td>${b.company || '-'}</td>
                                        <td>${b.booking_date}</td>
                                        <td>${formatTime12(b.preferred_time?.substring(0,5))}</td>
                                        <td>${b.purpose?.substring(0, 30)}${b.purpose?.length > 30 ? '...' : ''}</td>
                                        <td>${b.schedule_priority ? priorityBadge(b.schedule_priority) : '<span class="text-muted" title="Priority is set when the meeting is scheduled">—</span>'}</td>
                                        <td>${statusBadge(b.status)}</td>
                                        <td class="text-nowrap">
                                            <button class="btn btn-sm btn-outline-forest me-1" title="View details" onclick="viewAppointmentDetails('${b.id}')"><i class="bi bi-eye"></i></button>
                                            ${isCoordinator() ? `
                                                ${b.status === 'pending' ? `
                                                    <button class="btn btn-sm btn-outline-success me-1" title="Approve" onclick="handleBooking('${b.id}','accepted')"><i class="bi bi-check"></i></button>
                                                    <button class="btn btn-sm btn-outline-danger me-1" title="Reject" onclick="handleBooking('${b.id}','rejected')"><i class="bi bi-x"></i></button>
                                                ` : ''}
                                                <button class="btn btn-sm btn-outline-forest" title="Reschedule" onclick="openRescheduleModal('${b.id}','${b.booking_date}','${(b.preferred_time || '').substring(0,5)}',${b.duration || 30})"><i class="bi bi-calendar-event"></i></button>
                                            ` : ''}
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>`}
                </div>
            </div>
        `;
    } catch (err) {
        wrapper.innerHTML = '<div class="alert alert-danger">Failed to load bookings</div>';
    }
}

function filterBookings(status: string, btn: HTMLElement) {
    document.querySelectorAll('.d-flex .btn-outline-forest').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('table tbody tr').forEach((row: any) => {
        row.style.display = status === 'all' || row.dataset.status === status ? '' : 'none';
    });
}

async function handleBooking(id: string, status: string) {
    try {
        await api.updateBookingStatus(id, status);
        const who = currentUser?.fullName || currentUser?.full_name || 'User';
        showToast(status === 'accepted' ? `Booking approved by ${who}` : `Booking ${status} by ${who}`);
        renderBookings();
    } catch (err: any) {
        if (err.hasConflict) {
            showToast('This approval overlaps an existing meeting', 'warning');
            viewAppointmentDetails(id, err);
        } else {
            showToast(err.error || 'Failed', 'danger');
        }
    }
}

// ===== Reminders Page =====
async function renderReminders() {
    const wrapper = document.getElementById('content-wrapper')!;
    try {
        const reminders = await api.getReminders();

        wrapper.innerHTML = `
            <div class="content-header">
                <div>
                    <h4>Reminders</h4>
                    <div class="subtitle">Never miss an important task</div>
                </div>
                <button class="btn btn-gold" onclick="openReminderModal()"><i class="bi bi-plus-lg me-1"></i>Add Reminder</button>
            </div>
            <div class="card-premium">
                <div class="card-body">
                    ${reminders.length === 0 ? showEmptyState('bi-bell', 'No reminders') :
                    reminders.map((r: any) => `
                        <div class="task-item">
                            <span class="priority-dot ${r.priority}" style="margin-top:6px"></span>
                            <div class="task-info flex-grow-1">
                                <div class="task-title ${r.status === 'completed' ? 'completed' : ''}">${r.title}</div>
                                <div class="task-meta">${r.reminder_date} at ${formatTime12(r.reminder_time?.substring(0,5))} &middot; ${r.repeat_type} &middot; <span class="badge ${r.status === 'completed' ? 'bg-success' : 'bg-warning'}">${r.status}</span></div>
                            </div>
                            <div class="d-flex gap-1">
                                ${r.status !== 'completed' ? `<button class="btn btn-sm btn-outline-success" onclick="completeReminder('${r.id}')"><i class="bi bi-check-lg"></i></button>` : ''}
                                <button class="btn btn-sm btn-outline-forest" onclick="editReminder('${r.id}')"><i class="bi bi-pencil"></i></button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } catch (err) {
        wrapper.innerHTML = '<div class="alert alert-danger">Failed to load reminders</div>';
    }
}

async function completeReminder(id: string) {
    try {
        await api.completeReminder(id);
        showToast('Reminder completed');
        renderReminders();
    } catch (err: any) {
        showToast(err.error || 'Failed', 'danger');
    }
}

// ===== Tasks Page =====
async function renderTasks() {
    const wrapper = document.getElementById('content-wrapper')!;
    try {
        const [pending, completed, allTasks] = await Promise.all([
            api.getTasks('pending'),
            api.getTasks('completed'),
            api.getTasks()
        ]);

        wrapper.innerHTML = `
            <div class="content-header">
                <div>
                    <h4>Tasks</h4>
                    <div class="subtitle">${pending.length} pending &middot; ${completed.length} completed</div>
                </div>
                <button class="btn btn-gold" onclick="openTaskModal()"><i class="bi bi-plus-lg me-1"></i>Add Task</button>
            </div>
            <div class="row g-3">
                <div class="col-lg-8">
                    <div class="card-premium">
                        <div class="card-header"><i class="bi bi-list-task me-2"></i>Pending Tasks</div>
                        <div class="card-body">
                            ${pending.length === 0 ? showEmptyState('bi-check-circle', 'All tasks completed!') :
                            pending.map((t: any) => `
                                <div class="task-item">
                                    <div class="task-check" onclick="completeTask('${t.id}')"></div>
                                    <div class="task-info flex-grow-1" onclick="editTask('${t.id}')" style="cursor:pointer">
                                        <div class="task-title">${t.title}</div>
                                        <div class="task-meta"><span class="priority-dot ${t.priority}"></span> ${t.priority} ${t.due_date ? '&middot; Due ' + t.due_date : ''}</div>
                                    </div>
                                    <button class="btn btn-sm btn-outline-forest" onclick="editTask('${t.id}')"><i class="bi bi-pencil"></i></button>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card-premium">
                        <div class="card-header"><i class="bi bi-check-circle me-2"></i>Completed</div>
                        <div class="card-body" style="max-height:400px;overflow-y:auto">
                            ${completed.length === 0 ? showEmptyState('bi-inbox', 'No completed tasks') :
                            completed.slice(0, 10).map((t: any) => `
                                <div class="task-item">
                                    <div class="task-check completed"><i class="bi bi-check" style="font-size:11px"></i></div>
                                    <div class="task-info">
                                        <div class="task-title completed">${t.title}</div>
                                        <div class="task-meta">Completed</div>
                                    </div>
                                    <button class="btn btn-sm btn-outline-forest" onclick="reopenTask('${t.id}')"><i class="bi bi-arrow-counterclockwise"></i></button>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;
    } catch (err) {
        wrapper.innerHTML = '<div class="alert alert-danger">Failed to load tasks</div>';
    }
}

async function completeTask(id: string) {
    try {
        await api.completeTask(id);
        showToast('Task completed');
        renderTasks();
    } catch (err: any) {
        showToast(err.error || 'Failed', 'danger');
    }
}

async function reopenTask(id: string) {
    try {
        await api.reopenTask(id);
        showToast('Task reopened');
        renderTasks();
    } catch (err: any) {
        showToast(err.error || 'Failed', 'danger');
    }
}

// ===== Notifications Page =====
async function renderNotifications() {
    const wrapper = document.getElementById('content-wrapper')!;
    try {
        const notifications = await api.getNotifications();

        wrapper.innerHTML = `
            <div class="content-header">
                <div>
                    <h4>Notifications</h4>
                    <div class="subtitle">${notifications.filter((n: any) => !n.is_read).length} unread</div>
                </div>
                <button class="btn btn-outline-forest" onclick="markAllRead()"><i class="bi bi-check-all me-1"></i>Mark All Read</button>
            </div>
            <div class="card-premium">
                <div class="card-body p-0">
                    ${notifications.length === 0 ? showEmptyState('bi-inbox', 'No notifications') :
                    notifications.map((n: any) => `
                        <div class="notification-item ${!n.is_read ? 'unread' : ''}" onclick="markNotifRead('${n.id}',this)">
                            <div class="notif-title">${n.title}</div>
                            <div class="notif-message">${n.message}</div>
                            <div class="notif-time">${new Date(n.created_at).toLocaleString()}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } catch (err) {
        wrapper.innerHTML = '<div class="alert alert-danger">Failed to load notifications</div>';
    }
}

async function markNotifRead(id: string, el: HTMLElement) {
    try {
        await api.markNotifRead(id);
        el.classList.remove('unread');
        updateNotifBadge();
    } catch {}
}

async function markAllRead() {
    try {
        await api.markAllNotifsRead();
        showToast('All notifications marked as read');
        renderNotifications();
        updateNotifBadge();
    } catch {}
}

// ===== Excel Page =====
function renderExcel() {
    const wrapper = document.getElementById('content-wrapper')!;
    const now = new Date();
    const dayName = now.toLocaleDateString('en-US', { weekday: 'long' });

    wrapper.innerHTML = `
        <div class="hero-banner" style="margin-bottom:24px;">
            <div class="hero-top">
                <div>
                    <div class="hero-date-badge"><i class="bi bi-cloud-download"></i> Export</div>
                    <div class="hero-title">Data Manager</div>
                    <div class="hero-subtitle">Import and export your weekly data</div>
                </div>
                <div class="hero-quote"><p>Keep your data safe, export regularly</p></div>
            </div>
            <div class="hero-actions">
                <button class="btn-hero btn-hero-add" onclick="exportAllData()"><i class="bi bi-download"></i> Export All Data</button>
            </div>
        </div>

        <div class="row g-3 mb-4 fade-in">
            <div class="col-6 col-lg-3">
                <div class="stat-card forest-card" style="cursor:pointer" onclick="exportSchedulesExcel()">
                    <div class="stat-icon forest"><i class="bi bi-calendar-event"></i></div>
                    <div class="stat-label">Schedules</div>
                    <div style="font-size:11px;color:var(--emerald);margin-top:4px;font-weight:500;"><i class="bi bi-download me-1"></i>Export</div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="stat-card gold-card" style="cursor:pointer" onclick="exportBookingsToExcel()">
                    <div class="stat-icon gold"><i class="bi bi-calendar-check"></i></div>
                    <div class="stat-label">Bookings</div>
                    <div style="font-size:11px;color:var(--gold);margin-top:4px;font-weight:500;"><i class="bi bi-download me-1"></i>Export</div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="stat-card success-card" style="cursor:pointer" onclick="exportTasksExcel()">
                    <div class="stat-icon success"><i class="bi bi-list-task"></i></div>
                    <div class="stat-label">Tasks</div>
                    <div style="font-size:11px;color:var(--success);margin-top:4px;font-weight:500;"><i class="bi bi-download me-1"></i>Export</div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="stat-card info-card" style="cursor:pointer" onclick="exportRemindersExcel()">
                    <div class="stat-icon info"><i class="bi bi-bell"></i></div>
                    <div class="stat-label">Reminders</div>
                    <div style="font-size:11px;color:var(--info);margin-top:4px;font-weight:500;"><i class="bi bi-download me-1"></i>Export</div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-5">
                <div class="card-premium h-100">
                    <div class="card-header"><i class="bi bi-upload me-2"></i>Import Excel File</div>
                    <div class="card-body">
                        <div class="upload-zone" id="upload-zone" onclick="document.getElementById('excel-file-input').click()">
                            <i class="bi bi-cloud-arrow-up"></i>
                            <p class="mb-1 fw-semibold" style="font-size:14px">Click to upload or drag and drop</p>
                            <p class="mb-0" style="font-size:12px;color:var(--text-muted)">Supports .xlsx, .xls, .csv files</p>
                        </div>
                        <input type="file" id="excel-file-input" accept=".xlsx,.xls,.csv" style="display:none" onchange="uploadExcel()">
                        <button class="btn btn-forest w-100 mt-3" onclick="uploadExcel()"><i class="bi bi-upload me-1"></i>Upload File</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="card-premium h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-clock-history me-2"></i>Export History</span>
                        <span style="font-size:11px;color:var(--text-muted);">Last 7 days data</span>
                    </div>
                    <div class="card-body">
                        <div style="padding:16px;background:linear-gradient(135deg,var(--green-soft),rgba(52,167,123,0.05));border-radius:var(--radius);margin-bottom:16px;">
                            <div style="font-size:12px;font-weight:600;color:var(--forest);margin-bottom:4px;"><i class="bi bi-info-circle me-1"></i> Weekly Export</div>
                            <div style="font-size:12px;color:var(--text-secondary);">All exports include data from the last 7 days. A reminder is shown every weekend to keep your data backed up.</div>
                        </div>
                        <div class="d-flex flex-column gap-2">
                            <div class="d-flex justify-content-between align-items-center p-2 rounded" style="background:var(--green-soft);cursor:pointer;" onclick="exportAllData()">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-file-earmark-zip" style="color:var(--forest);font-size:16px;"></i>
                                    <div>
                                        <div style="font-size:13px;font-weight:600;">Full Export (All Data)</div>
                                        <div style="font-size:11px;color:var(--text-muted);">Schedules, Bookings, Tasks, Reminders, Focus</div>
                                    </div>
                                </div>
                                <button class="btn btn-sm btn-forest"><i class="bi bi-download"></i></button>
                            </div>
                            <div class="d-flex justify-content-between align-items-center p-2 rounded" style="background:rgba(27,94,59,0.02);cursor:pointer;" onclick="exportSchedulesExcel()">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-calendar3" style="color:var(--forest);font-size:16px;"></i>
                                    <div>
                                        <div style="font-size:13px;font-weight:500;">Schedules Only</div>
                                        <div style="font-size:11px;color:var(--text-muted);">Last 7 days of meetings</div>
                                    </div>
                                </div>
                                <button class="btn btn-sm btn-outline-forest"><i class="bi bi-download"></i></button>
                            </div>
                            <div class="d-flex justify-content-between align-items-center p-2 rounded" style="background:rgba(27,94,59,0.02);cursor:pointer;" onclick="exportBookingsToExcel()">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-calendar-check" style="color:var(--gold);font-size:16px;"></i>
                                    <div>
                                        <div style="font-size:13px;font-weight:500;">Bookings Only</div>
                                        <div style="font-size:11px;color:var(--text-muted);">All booking requests</div>
                                    </div>
                                </div>
                                <button class="btn btn-sm btn-outline-forest"><i class="bi bi-download"></i></button>
                            </div>
                            <div class="d-flex justify-content-between align-items-center p-2 rounded" style="background:rgba(27,94,59,0.02);cursor:pointer;" onclick="exportTasksExcel()">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-list-task" style="color:var(--success);font-size:16px;"></i>
                                    <div>
                                        <div style="font-size:13px;font-weight:500;">Tasks Only</div>
                                        <div style="font-size:11px;color:var(--text-muted);">All tasks with status</div>
                                    </div>
                                </div>
                                <button class="btn btn-sm btn-outline-forest"><i class="bi bi-download"></i></button>
                            </div>
                            <div class="d-flex justify-content-between align-items-center p-2 rounded" style="background:rgba(27,94,59,0.02);cursor:pointer;" onclick="exportRemindersExcel()">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-bell" style="color:var(--info);font-size:16px;"></i>
                                    <div>
                                        <div style="font-size:13px;font-weight:500;">Reminders Only</div>
                                        <div style="font-size:11px;color:var(--text-muted);">All reminders with repeat info</div>
                                    </div>
                                </div>
                                <button class="btn btn-sm btn-outline-forest"><i class="bi bi-download"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    const zone = document.getElementById('upload-zone');
    if (zone) {
        zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('dragover'); });
        zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
        zone.addEventListener('drop', (e) => {
            e.preventDefault();
            zone.classList.remove('dragover');
            const input = document.getElementById('excel-file-input') as HTMLInputElement;
            if (e.dataTransfer?.files.length) {
                input.files = e.dataTransfer.files;
                uploadExcel();
            }
        });
    }
}

// ===== Settings Page =====
function renderSettings() {
    const wrapper = document.getElementById('content-wrapper')!;
    const isCeo = currentUser?.role === 'ceo';
    wrapper.innerHTML = `
        <div class="content-header">
            <div>
                <h4>Settings</h4>
                <div class="subtitle">Manage your account and data</div>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-lg-6">
                <div class="card-premium">
                    <div class="card-header"><i class="bi bi-person me-2"></i>Profile</div>
                    <div class="card-body">
                        <div class="mb-3"><label class="form-label">Name</label><input type="text" class="form-control" value="${currentUser?.fullName || currentUser?.full_name || ''}" disabled></div>
                        <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" value="${currentUser?.email || ''}" disabled></div>
                        <div class="mb-3"><label class="form-label">Role</label><input type="text" class="form-control" value="${currentUser?.role?.toUpperCase() || ''}" disabled></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card-premium">
                    <div class="card-header"><i class="bi bi-clock me-2"></i>Working Hours</div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-6"><label class="form-label">Start</label><input type="time" class="form-control" value="09:00"></div>
                            <div class="col-6"><label class="form-label">End</label><input type="time" class="form-control" value="18:00"></div>
                        </div>
                    </div>
                </div>
            </div>
            ${isCeo ? `
            <div class="col-12">
                <div class="card-premium" style="border:1px solid rgba(217,79,79,0.2);">
                    <div class="card-header" style="background:rgba(217,79,79,0.04);color:var(--danger);"><i class="bi bi-exclamation-triangle me-2"></i>Data Management</div>
                    <div class="card-body">
                        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:20px;">
                            <div>
                                <div style="font-size:14px;font-weight:600;color:var(--text);margin-bottom:4px;">Clear All Data</div>
                                <div style="font-size:12.5px;color:var(--text-secondary);max-width:500px;">This will permanently delete all schedules, bookings, tasks, reminders, notifications, focus sessions, audit logs, and excel data. Users will NOT be deleted. This action cannot be undone.</div>
                            </div>
                            <button class="btn btn-danger" onclick="confirmClearAllData()" style="white-space:nowrap;flex-shrink:0;"><i class="bi bi-trash me-1"></i>Clear All Data</button>
                        </div>
                    </div>
                </div>
            </div>
            ` : ''}
        </div>
    `;
}

function confirmClearAllData() {
    const confirmed = confirm('Are you absolutely sure you want to delete ALL data?\n\nThis includes:\n- All schedules\n- All bookings\n- All tasks\n- All reminders\n- All notifications\n- All focus sessions\n- All audit logs\n- All excel data\n\nUsers will NOT be deleted.\n\nThis CANNOT be undone.');
    if (!confirmed) return;

    const doubleConfirm = confirm('FINAL CONFIRMATION: Type "DELETE" mentally and click OK to proceed with deleting everything.');
    if (!doubleConfirm) return;

    api.clearAllData().then((result) => {
        showToast('All data has been cleared successfully', 'success');
        setTimeout(() => showPage('dashboard'), 1500);
    }).catch((err: any) => {
        showToast(err.error || 'Failed to clear data', 'danger');
    });
}

// ===== Modals =====
function openScheduleModal(schedule?: any, defaultTime?: string, defaultDate?: string) {
    const modal = new (window as any).bootstrap.Modal(document.getElementById('scheduleModal'));
    document.getElementById('scheduleModalTitle')!.textContent = schedule ? 'Edit Schedule' : 'Add Schedule';
    (document.getElementById('sch-id') as HTMLInputElement).value = schedule?.id || '';
    (document.getElementById('sch-title') as HTMLInputElement).value = schedule?.title || '';
    (document.getElementById('sch-description') as HTMLTextAreaElement).value = schedule?.description || '';
    (document.getElementById('sch-date') as HTMLInputElement).value = schedule?.schedule_date || defaultDate || dateToKey(new Date());
    (document.getElementById('sch-start') as HTMLInputElement).value = schedule?.start_time?.substring(0,5) || defaultTime || '09:00';
    (document.getElementById('sch-end') as HTMLInputElement).value = schedule?.end_time?.substring(0,5) || '';
    (document.getElementById('sch-type') as HTMLSelectElement).value = schedule?.schedule_type || 'other';
    (document.getElementById('sch-location') as HTMLInputElement).value = schedule?.location || '';
    (document.getElementById('sch-participants') as HTMLInputElement).value = schedule?.participants?.join(', ') || '';
    (document.getElementById('sch-priority') as HTMLSelectElement).value = schedule?.priority || 'medium';
    (document.getElementById('sch-reminder') as HTMLInputElement).value = schedule?.reminder_minutes || '15';
    (document.getElementById('sch-status') as HTMLSelectElement).value = schedule?.status || 'active';
    (document.getElementById('sch-ceo-appt') as HTMLInputElement).checked = schedule?.is_ceo_appointment === true;
    document.getElementById('conflict-alert')!.classList.add('d-none');
    modal.show();
}

function openBookingModal() {
    const modal = new (window as any).bootstrap.Modal(document.getElementById('bookingModal'));
    (document.getElementById('bk-date') as HTMLInputElement).value = new Date().toISOString().split('T')[0];
    modal.show();
}

function openReminderModal(reminder?: any) {
    const modal = new (window as any).bootstrap.Modal(document.getElementById('reminderModal'));
    document.getElementById('reminderModalTitle')!.textContent = reminder ? 'Edit Reminder' : 'Add Reminder';
    (document.getElementById('rem-id') as HTMLInputElement).value = reminder?.id || '';
    (document.getElementById('rem-title') as HTMLInputElement).value = reminder?.title || '';
    (document.getElementById('rem-description') as HTMLTextAreaElement).value = reminder?.description || '';
    (document.getElementById('rem-date') as HTMLInputElement).value = reminder?.reminder_date || new Date().toISOString().split('T')[0];
    (document.getElementById('rem-time') as HTMLInputElement).value = reminder?.reminder_time?.substring(0,5) || '09:00';
    (document.getElementById('rem-repeat') as HTMLSelectElement).value = reminder?.repeat_type || 'once';
    (document.getElementById('rem-priority') as HTMLSelectElement).value = reminder?.priority || 'medium';
    modal.show();
}

function openTaskModal(task?: any) {
    const modal = new (window as any).bootstrap.Modal(document.getElementById('taskModal'));
    document.getElementById('taskModalTitle')!.textContent = task ? 'Edit Task' : 'Add Task';
    (document.getElementById('tsk-id') as HTMLInputElement).value = task?.id || '';
    (document.getElementById('tsk-title') as HTMLInputElement).value = task?.title || '';
    (document.getElementById('tsk-description') as HTMLTextAreaElement).value = task?.description || '';
    (document.getElementById('tsk-due') as HTMLInputElement).value = task?.due_date || '';
    (document.getElementById('tsk-priority') as HTMLSelectElement).value = task?.priority || 'medium';
    modal.show();
}

function openFocusModal() {
    const modal = new (window as any).bootstrap.Modal(document.getElementById('focusModal'));
    (document.getElementById('foc-date') as HTMLInputElement).value = new Date().toISOString().split('T')[0];
    modal.show();
}

function openFindTimeModal() {
    const modal = new (window as any).bootstrap.Modal(document.getElementById('findTimeModal'));
    (document.getElementById('ft-date') as HTMLInputElement).value = new Date().toISOString().split('T')[0];
    document.getElementById('available-slots-list')!.innerHTML = '';
    modal.show();
}

// Auto-calculate end time (30 min after start) when start time changes
document.getElementById('sch-start')?.addEventListener('change', (e) => {
    const startVal = (e.target as HTMLInputElement).value;
    const endField = document.getElementById('sch-end') as HTMLInputElement;
    if (startVal && (!endField.value || endField.value <= startVal)) {
        const [h, m] = startVal.split(':').map(Number);
        const endM = m + 30;
        const endH = h + Math.floor(endM / 60);
        endField.value = `${endH.toString().padStart(2, '0')}:${(endM % 60).toString().padStart(2, '0')}`;
    }
});

// ===== Modal Save Handlers =====
async function saveScheduleForm(overrideConflict: boolean) {
    const id = (document.getElementById('sch-id') as HTMLInputElement).value;
    const data = {
        title: (document.getElementById('sch-title') as HTMLInputElement).value,
        description: (document.getElementById('sch-description') as HTMLTextAreaElement).value,
        date: (document.getElementById('sch-date') as HTMLInputElement).value,
        startTime: (document.getElementById('sch-start') as HTMLInputElement).value,
        endTime: (document.getElementById('sch-end') as HTMLInputElement).value,
        scheduleType: (document.getElementById('sch-type') as HTMLSelectElement).value,
        location: (document.getElementById('sch-location') as HTMLInputElement).value,
        participants: (document.getElementById('sch-participants') as HTMLInputElement).value.split(',').map((s: string) => s.trim()).filter(Boolean),
        priority: (document.getElementById('sch-priority') as HTMLSelectElement).value,
        reminderMinutes: parseInt((document.getElementById('sch-reminder') as HTMLInputElement).value),
        status: (document.getElementById('sch-status') as HTMLSelectElement).value,
        isCeoAppointment: (document.getElementById('sch-ceo-appt') as HTMLInputElement)?.checked === true,
        overrideConflict: overrideConflict
    };

    if (!data.title || !data.date || !data.startTime || !data.endTime) {
        showToast('Please fill required fields', 'warning');
        return;
    }
    if (data.endTime <= data.startTime) {
        showToast('End time must be after start time', 'warning');
        return;
    }

    try {
        if (id) {
            await api.updateSchedule(id, data);
            showToast(overrideConflict ? 'Saved with conflict override' : 'Schedule updated');
        } else {
            await api.createSchedule(data);
            showToast(overrideConflict ? 'Created with conflict override' : 'Schedule created');
        }
        bootstrap.Modal.getInstance(document.getElementById('scheduleModal'))?.hide();
        if (currentPage === 'dashboard') renderDashboard();
        else if (currentPage === 'schedule') renderSchedule();
        else if (currentPage === 'calendar') renderCalendar();
    } catch (err: any) {
        if (err.hasConflict) {
            const alert = document.getElementById('conflict-alert')!;
            const list = (err.conflicts || []).map((c: any) => `&bull; <strong>${c.title}</strong> (${c.priorityLabel || c.priority}) ${formatTime12(c.startTime)}-${formatTime12(c.endTime)}${c.ownerName ? ' \u2014 ' + c.ownerName : ''}`).join('<br>');
            let slotsHtml = '';
            if (err.suggestedSlots?.length) {
                slotsHtml = '<div class="mt-2" style="font-size:12px;"><strong>Suggested slots:</strong> ' + err.suggestedSlots.map((s: any) => `${formatTime12(s.start_time || s.start)}-${formatTime12(s.end_time || s.end)}`).join(', ') + '</div>';
            }
            alert.innerHTML = `<i class="bi bi-exclamation-triangle me-2"></i><strong>${err.error || 'Time conflict detected'}</strong><br>${list}${slotsHtml}
                <div class="d-flex flex-wrap gap-2 mt-2">
                    <button class="btn btn-sm btn-outline-secondary" onclick="closeScheduleModal()">Cancel</button>
                    <button class="btn btn-sm btn-outline-forest" onclick="adjustScheduleTime()"><i class="bi bi-pencil me-1"></i>Adjust Time</button>
                    <button class="btn btn-sm btn-danger" onclick="confirmAndOverrideSave()"><i class="bi bi-exclamation-triangle me-1"></i>Override Conflict &amp; Save</button>
                </div>`;
            alert.classList.remove('d-none');
        } else {
            showToast(err.error || 'Failed to save', 'danger');
        }
    }
}

document.getElementById('save-schedule-btn')?.addEventListener('click', () => saveScheduleForm(false));

// ===== Conflict handling actions =====
function closeScheduleModal() {
    (window as any).bootstrap?.Modal?.getInstance(document.getElementById('scheduleModal'))?.hide();
}

/** Dismiss the warning and let the user pick a different time. */
function adjustScheduleTime() {
    const alert = document.getElementById('conflict-alert')!;
    alert.classList.add('d-none');
    alert.innerHTML = '';
    (document.getElementById('sch-start') as HTMLInputElement)?.focus();
}

/** Overriding a conflict requires an explicit confirmation before saving. */
function confirmAndOverrideSave() {
    if (window.confirm('This meeting overlaps another meeting. Save it anyway and record the override in the audit trail?')) {
        saveScheduleForm(true);
    }
}

function confirmAndOverrideReschedule() {
    if (window.confirm('This new time overlaps an existing CEO meeting. Reschedule anyway and record the override in the audit trail?')) {
        submitReschedule(true);
    }
}

document.getElementById('save-booking-btn')?.addEventListener('click', async () => {
    const data = {
        name: (document.getElementById('bk-name') as HTMLInputElement).value,
        email: (document.getElementById('bk-email') as HTMLInputElement).value,
        company: (document.getElementById('bk-company') as HTMLInputElement).value,
        purpose: (document.getElementById('bk-purpose') as HTMLTextAreaElement).value,
        date: (document.getElementById('bk-date') as HTMLInputElement).value,
        time: (document.getElementById('bk-time') as HTMLInputElement).value,
        duration: parseInt((document.getElementById('bk-duration') as HTMLSelectElement).value),
        notes: (document.getElementById('bk-notes') as HTMLInputElement).value,
        address: (document.getElementById('bk-address') as HTMLInputElement)?.value || '',
        place: (document.getElementById('bk-place') as HTMLInputElement)?.value || '',
        phone: (document.getElementById('bk-phone') as HTMLInputElement)?.value || '',
        visitorType: (document.getElementById('bk-visitor-type') as HTMLSelectElement)?.value || 'external',
        frequency: (document.getElementById('bk-frequency') as HTMLSelectElement)?.value || 'once',
        what: (document.getElementById('bk-topic') as HTMLTextAreaElement)?.value || '',
    };

    if (!data.name || !data.email || !data.purpose || !data.date || !data.time) {
        showToast('Please fill required fields', 'warning');
        return;
    }

    try {
        await api.createBooking(data);
        showToast('Booking request submitted');
        bootstrap.Modal.getInstance(document.getElementById('bookingModal'))?.hide();
        if (currentPage === 'bookings') renderBookings();
    } catch (err: any) {
        showToast(err.error || 'Failed', 'danger');
    }
});

document.getElementById('save-reminder-btn')?.addEventListener('click', async () => {
    const id = (document.getElementById('rem-id') as HTMLInputElement).value;
    const data = {
        title: (document.getElementById('rem-title') as HTMLInputElement).value,
        description: (document.getElementById('rem-description') as HTMLTextAreaElement).value,
        date: (document.getElementById('rem-date') as HTMLInputElement).value,
        time: (document.getElementById('rem-time') as HTMLInputElement).value,
        repeatType: (document.getElementById('rem-repeat') as HTMLSelectElement).value,
        priority: (document.getElementById('rem-priority') as HTMLSelectElement).value,
    };

    if (!data.title || !data.date || !data.time) {
        showToast('Please fill required fields', 'warning');
        return;
    }

    try {
        if (id) {
            await api.updateReminder(id, data);
            showToast('Reminder updated');
        } else {
            await api.createReminder(data);
            showToast('Reminder created');
        }
        bootstrap.Modal.getInstance(document.getElementById('reminderModal'))?.hide();
        if (currentPage === 'reminders') renderReminders();
    } catch (err: any) {
        showToast(err.error || 'Failed', 'danger');
    }
});

document.getElementById('save-task-btn')?.addEventListener('click', async () => {
    const id = (document.getElementById('tsk-id') as HTMLInputElement).value;
    const data = {
        title: (document.getElementById('tsk-title') as HTMLInputElement).value,
        description: (document.getElementById('tsk-description') as HTMLTextAreaElement).value,
        dueDate: (document.getElementById('tsk-due') as HTMLInputElement).value || null,
        priority: (document.getElementById('tsk-priority') as HTMLSelectElement).value,
    };

    if (!data.title) {
        showToast('Please enter a title', 'warning');
        return;
    }

    try {
        if (id) {
            await api.updateTask(id, data);
            showToast('Task updated');
        } else {
            await api.createTask(data);
            showToast('Task created');
        }
        bootstrap.Modal.getInstance(document.getElementById('taskModal'))?.hide();
        if (currentPage === 'tasks') renderTasks();
    } catch (err: any) {
        showToast(err.error || 'Failed', 'danger');
    }
});

document.getElementById('save-focus-btn')?.addEventListener('click', async () => {
    const data = {
        title: (document.getElementById('foc-title') as HTMLInputElement).value || 'Focus Time',
        date: (document.getElementById('foc-date') as HTMLInputElement).value,
        startTime: (document.getElementById('foc-start') as HTMLInputElement).value,
        endTime: (document.getElementById('foc-end') as HTMLInputElement).value,
    };

    if (!data.date || !data.startTime || !data.endTime) {
        showToast('Please fill required fields', 'warning');
        return;
    }

    try {
        await api.createFocusSession(data);
        showToast('Focus time scheduled');
        bootstrap.Modal.getInstance(document.getElementById('focusModal'))?.hide();
    } catch (err: any) {
        showToast(err.error || 'Failed', 'danger');
    }
});

document.getElementById('save-reschedule-btn')?.addEventListener('click', () => submitReschedule(false));

// ===== Edit helpers =====
async function editSchedule(id: string) {
    try {
        const schedule = await api.get(`/schedules/${id}`);
        openScheduleModal(schedule);
    } catch {
        showToast('Failed to load schedule', 'danger');
    }
}

async function editReminder(id: string) {
    try {
        const reminder = await api.get(`/reminders/${id}`);
        openReminderModal(reminder);
    } catch {
        showToast('Failed to load reminder', 'danger');
    }
}

async function editTask(id: string) {
    try {
        const task = await api.get(`/tasks/${id}`);
        openTaskModal(task);
    } catch {
        showToast('Failed to load task', 'danger');
    }
}

// ===== Find Available Slots =====
async function findAvailableSlots() {
    const date = (document.getElementById('ft-date') as HTMLInputElement).value;
    const duration = parseInt((document.getElementById('ft-duration') as HTMLSelectElement).value);
    const el = document.getElementById('available-slots-list')!;

    if (!date) { el.innerHTML = '<div class="alert alert-warning">Please select a date</div>'; return; }

    try {
        const slots = await api.getAvailableSlots(date, duration);
        if (slots.length === 0) {
            el.innerHTML = '<div class="alert alert-info">No available slots for this date</div>';
            return;
        }
        el.innerHTML = slots.map((s: any) => `
            <div class="d-flex justify-content-between align-items-center p-2 rounded mb-1" style="background:rgba(62,142,104,0.06)">
                <span style="font-size:13px">${formatTime12(s.start_time)} - ${formatTime12(s.end_time)}</span>
                <button class="btn btn-sm btn-outline-forest" onclick="document.getElementById('sch-date').value='${date}';document.getElementById('sch-start').value='${s.start_time}';document.getElementById('sch-end').value='${s.end_time}';bootstrap.Modal.getInstance(document.getElementById('findTimeModal'))?.hide();openScheduleModal(null,'${s.start_time}','${date}')">
                    <i class="bi bi-plus"></i> Book
                </button>
            </div>
        `).join('');
    } catch (err: any) {
        el.innerHTML = `<div class="alert alert-danger">${err.error || 'Failed to find slots'}</div>`;
    }
}

// ===== Notification Polling =====
let notifPollInterval: any;

function startNotifPolling() {
    updateNotifBadge();
    notifPollInterval = setInterval(updateNotifBadge, 30000);
}

async function updateNotifBadge() {
    try {
        const { count } = await api.getUnreadNotifCount();
        const badges = document.querySelectorAll('#notif-badge, #mobile-notif-badge');
        badges.forEach(badge => {
            badge.textContent = count.toString();
            badge.classList.toggle('d-none', count === 0);
        });
    } catch {}
}
